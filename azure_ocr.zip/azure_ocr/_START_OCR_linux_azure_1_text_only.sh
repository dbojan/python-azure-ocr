#!/bin/bash
#start with xterm -e

#2026-02-24-2

python_name=python

#test if tools exist
for c in pdftoppm "$python_name"
do
	if ! command -v $c >/dev/null
	then
		echo $c is missing
	fi
done



# Ensure we are in the script's directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OCR_DIR="$SCRIPT_DIR/ocr"

# Create ocr dir if it doesn't exist
mkdir -p "$OCR_DIR"

cd "$OCR_DIR" || exit


# 1. Convert PDF to Images
for g in *.pdf *.PDF; do
    [ -e "$g" ] || continue
    echo "Converting $g to img..."
    
    # Using TIFF as requested
    pdftoppm -aa yes -aaVector yes  -tiff -tiffcompression packbits  -gray "$g" "${g%.pdf}-img"

    mv "$g" ../
done


if [ -z "$(ls -A "$OCR_DIR")" ]; then
    echo "Error: No files found in $OCR_DIR. Nothing to process."
    read -p "Press [Enter] to exit..." 
    exit 1
fi


cd "$SCRIPT_DIR" || exit

# 2. Cleanup old OCR text files
rm -f *-out_Ocr_*.txt

# 3. List files and wait for user
echo "Files ready for OCR:"
ls "$OCR_DIR" | sort  # Added sort here for visual clarity
echo ""

# FIX: Using -u /dev/tty ensures it waits even in xterm/scripts
echo "Press [Enter] key to start OCR..."
read -r dummy < /dev/tty
echo ""

# 4. Run Python OCR scripts
echo "OCR of files in ocr folder..."
"$python_name" _azure_ocr1.py

# 5. Process newlines
ST_INPUT_FILE="ocr-out_Ocr_NoColumnFile.txt"
if [ -f "$ST_INPUT_FILE" ]; then
    echo "Removing extra newlines..."
    "$python_name" _remove_newlines1.py "$ST_INPUT_FILE"
fi

# 6. Cleanup
mv ocr/* . 2>/dev/null

echo "Finished."
read -p "Press [Enter] to exit..." 