see readme.md at https://github.com/dbojan/python-azure-ocr/

put pdf in ocr folder, start .bat file. azure account needed.
enter your data in azure.py

	endpoint = "https://.."
	key = "123.."


pdf2png from xpdf package is also included

2025-08-03-1