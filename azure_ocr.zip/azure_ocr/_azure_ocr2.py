ver = '2026-4-2-1'

r'''

to install on windows:
pip install -U azure-ai-documentintelligence
pip install -U python-docx

copy pdf to ocr folder.
start bat file.


on linux debian:
if not installed install python3: 
sudo apt-get install python3

install 'python3-pip', which will be later used as just 'pip': 
sudo apt install python3-pip

and finally, use '--break-system-packages' option to be allowed to install system wide packages, using just 'pip':
pip install --break-system-packages -U azure-ai-documentintelligence
pip install --break-system-packages -U python-docx

install poppler for your distro.

copy pdf to ocr folder.
start sh file.

program will ocr files saved in 'ocr' folder, and save result in ocr.text, utf-8 encoded.
on windows, put images in ocr folder, and start program by double clicking on 'azure_ocr.bat'
you can use ghostscript to conver pdf to images: 
gs\bin\gswin32c.exe -sCompression=pack -dTextAlphaBits=4 -dGraphicsAlphaBits=4  -sDEVICE=tiffgray -r300 -o output-%03d.tif input.pdf
use output-%%03d.tif if running inside bat file.

or xpdf:
xpdf\pdftopng.exe -r 300 -gray  source destination

'''

#https://learn.microsoft.com/en-us/azure/ai-services/document-intelligence/quickstarts/get-started-sdks-rest-api?view=doc-intel-4.0.0&preserve-view=true&pivots=programming-language-python
#create document inteligence resource: north eu, free
#enter key and endpoint

#https://github.com/Azure-Samples/document-intelligence-code-samples/tree/main
#https://github.com/Azure-Samples/document-intelligence-code-samples/blob/main/Python(v4.0)/Layout_model/sample_analyze_layout.py


key = ""
endpoint = ""

st_model="prebuilt-read" #cheaper, no tables; 1000 pages=$1.5
#uncomment line below to detect tables
st_model="prebuilt-layout" #more expensive, tables; 1000 pages=$10
print('ver:', ver)
print('using', st_model, 'model')

table_width_is_page_width       = 1  # keep this on. 1 = stretch table to full writable page width (respects margins), 0 = keep original proportions

detect_horiz_alig_text_in_table = 0  # 1 = detect horizontal centering in table cells, 0 = always left-align
detect_vert_alig_text_in_table  = 0  # 1 = detect vertical centering in table cells,   0 = always top-align
detect_column_width_table       = 1  # 1 = detect column widths from bounding boxes,   0 = let Word auto-size
detect_row_height_table         = 0  # 1 = detect row heights from bounding boxes,     0 = let Word auto-size

# Alignment sensitivity (fraction of cell dimension, 0.0-1.0).
# LOWER value = stricter (less likely to call something centered).
# HIGHER value = looser (more likely to call something centered).
# horiz: tolerance for |space_left - space_right| relative to cell width.
#   0.10 = strict (spaces must match within 10%), 0.20 = loose.
#   The minimum space required on each side = sensitivity / 3.
# vert:  tolerance for |space_top - space_bottom| relative to cell height.
#   0.15 = strict, 0.25 = loose.
horiz_align_sensitivity = 0.15   # default: 15% of cell width
vert_align_sensitivity  = 0.20   # default: 20% of cell height

save_azure_output = 0  # 1 = save raw Azure JSON response to <filename>.azure.json for each input file, 0 = skip


import os
import time
import re
from azure.core.credentials import AzureKeyCredential
from azure.ai.documentintelligence import DocumentIntelligenceClient
from azure.ai.documentintelligence.models import AnalyzeResult
from azure.ai.documentintelligence.models import AnalyzeDocumentRequest
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.shared import Pt, Inches
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from io import BytesIO
from docx.shared import Mm
import sys
import json


if key == "" or endpoint == "":
	print("FATAL ERROR: missing key or endpoint variables.")
	input("Press Enter to exit...")
	sys.exit()

indir = 'ocr'

if not os.path.isdir(indir):
	print('Please pass *existing* directory name')
	exit()

dirWithFiles = os.listdir(indir)
dirWithFiles.sort()


intCounter = 0
intMax = len(dirWithFiles)
output_docx_path = "output_"+ st_model + ".docx"
txt_output_path = os.path.splitext(output_docx_path)[0] + "-lines-mode.txt"
full_text_in_lines = ''

if os.path.exists(output_docx_path):
	os.remove(output_docx_path)

if os.path.exists(txt_output_path):
	os.remove(txt_output_path)

# Create ONE Word document to append to

doc = Document()
#a4, margins
section = doc.sections[0]
section.page_height = Mm(297)
section.page_width = Mm(210)
section.left_margin = Mm(25.4)
section.right_margin = Mm(25.4)
section.top_margin = Mm(25.4)
section.bottom_margin = Mm(25.4)
section.header_distance = Mm(12.7)
section.footer_distance = Mm(12.7)


#no auto space after para
style = doc.styles['Normal']
style.paragraph_format.space_after = Pt(0)
style.paragraph_format.space_before = Pt(0)
#style.paragraph_format.line_spacing = Pt(12)  # Optional: control line spacing

# Access the font object of the 'Normal' style
font = style.font
# Set the desired font name and size
font.name = 'Times New Roman'  # Example: Set font to Arial
#font.name = 'Calibri'
font.size = Pt(12)   # Example: Set font size to 12 points




def reconstruct_lines_from_words(result, y_bucket_threshold=10):
	all_words = []

	for page in result.pages:
		for word in page.words:
			if word.content.strip() and word.polygon:
				coords = word.polygon
				x_coords = coords[0::2]
				y_coords = coords[1::2]

				x_min = min(x_coords)
				x_max = max(x_coords)
				y_min = min(y_coords)
				y_max = max(y_coords)
				y_center = (y_min + y_max) / 2

				all_words.append({
					"text": clean_text(word.content),
					"x_min": x_min,
					"x_max": x_max,
					"y_center": y_center
				})

	# Step 1: Bucket words by y_center into lines
	lines = []
	for word in sorted(all_words, key=lambda w: w["y_center"]):
		placed = False
		for line in lines:
			if abs(word["y_center"] - line["y_center"]) <= y_bucket_threshold:
				line["words"].append(word)
				line["y_center"] = (line["y_center"] * len(line["words"]) + word["y_center"]) / (len(line["words"]) + 1)
				placed = True
				break
		if not placed:
			lines.append({
				"y_center": word["y_center"],
				"words": [word]
			})

	# Step 2: Sort words in each line left to right
	for line in lines:
		line["words"].sort(key=lambda w: w["x_min"])

	# Step 3: Sort lines top to bottom
	lines.sort(key=lambda l: l["y_center"])

	# Step 4: Write to file
	text_output = ""
	for line in lines:
		line_text = " ".join(w["text"] for w in line["words"])
		text_output += line_text.strip() + "\n"
	text_output += "\n"

	return text_output


def get_cell_bbox(cell):
	"""Return (left, right, top, bottom) of the cell boundary polygon in raw units.
	Returns None if no polygon is available."""
	for region in (cell.bounding_regions or []):
		p = region.polygon
		if p and len(p) >= 8:
			xs = p[0::2]
			ys = p[1::2]
			return min(xs), max(xs), min(ys), max(ys)
	return None


def build_word_map(result):
	"""Build a dict mapping word-span-offset -> (x_min, x_max, y_min, y_max).

	Azure returns word-level bounding polygons in result.pages[].words[].
	Each word has a .span (singular) with .offset.  We index by offset so we
	can quickly look up which pixel rectangle a given text span occupies.
	"""
	word_map = {}
	for page in result.pages:
		for word in page.words:
			if not word.polygon:
				continue
			p = word.polygon
			xs = p[0::2]; ys = p[1::2]
			# word.span is singular (not a list) for page-level words
			off = word.span.offset if hasattr(word.span, 'offset') else word.span['offset']
			word_map[off] = (min(xs), max(xs), min(ys), max(ys))
	return word_map


def get_content_bbox_from_words(cell, word_map):
	"""Return tight bounding box of all words belonging to this cell.

	Looks up each word whose span offset falls within any of the cell's spans.
	This gives the actual text position inside the cell, distinct from the cell
	boundary — essential for accurate alignment detection.
	Returns (left, right, top, bottom) in raw units, or None if no words found.
	"""
	xs = []; ys = []
	for span in (cell.spans or []):
		off   = span.offset if hasattr(span, 'offset') else span['offset']
		length = span.length if hasattr(span, 'length') else span['length']
		for word_off, (wx1, wx2, wy1, wy2) in word_map.items():
			if off <= word_off < off + length:
				xs.extend([wx1, wx2])
				ys.extend([wy1, wy2])
	if not xs:
		return None
	return min(xs), max(xs), min(ys), max(ys)


def build_grid_lines(table_data, num_cols, num_rows):
	"""
	Reconstruct column x-boundaries and row y-boundaries from ALL cell polygons.

	For each column boundary i (0 … num_cols), we collect the left-edge x of every
	cell whose column_index == i, and the right-edge x of every cell whose
	column_index + column_span - 1 == i.  The median of those gives a reliable
	grid line position even when many cells span multiple columns.

	Same logic for rows using top/bottom y edges.

	Returns:
	  col_x  – list of num_cols+1 x-positions in raw Azure units (pixels or inches)
	  row_y  – list of num_rows+1 y-positions in raw Azure units
	"""
	def median(lst):
		if not lst:
			return None
		s = sorted(lst)
		n = len(s)
		return s[n // 2] if n % 2 else (s[n // 2 - 1] + s[n // 2]) / 2

	# Collect left/right x candidates for each grid line index
	col_lefts  = [[] for _ in range(num_cols + 1)]
	row_tops   = [[] for _ in range(num_rows + 1)]

	for cell in table_data.cells:
		bbox = get_cell_bbox(cell)
		if bbox is None:
			continue
		left, right, top, bottom = bbox
		ci = cell.column_index
		cs = cell.column_span or 1
		ri = cell.row_index
		rs = cell.row_span or 1

		col_lefts[ci].append(left)           # left edge of this column
		col_lefts[ci + cs].append(right)     # right edge of last spanned column
		row_tops[ri].append(top)             # top edge of this row
		row_tops[ri + rs].append(bottom)     # bottom edge of last spanned row

	col_x = [median(pts) for pts in col_lefts]
	row_y = [median(pts) for pts in row_tops]

	# Fill any None gaps by linear interpolation between known neighbours
	def fill_none(arr):
		n = len(arr)
		# forward fill from first known
		for i in range(n):
			if arr[i] is not None:
				break
		else:
			return arr  # all None, nothing to do
		result = list(arr)
		# fill leading Nones
		first_known = next(j for j in range(n) if arr[j] is not None)
		for j in range(first_known):
			result[j] = arr[first_known]
		# interpolate interior and trailing Nones
		i = 0
		while i < n:
			if result[i] is None:
				# find next known
				j = i + 1
				while j < n and result[j] is None:
					j += 1
				if j < n:
					v0 = result[i - 1]
					v1 = result[j]
					steps = j - (i - 1)
					for k in range(i, j):
						result[k] = v0 + (v1 - v0) * (k - (i - 1)) / steps
				else:
					for k in range(i, n):
						result[k] = result[i - 1]
				i = j
			else:
				i += 1
		return result

	col_x = fill_none(col_x)
	row_y = fill_none(row_y)

	return col_x, row_y


def infer_cell_alignment(cell, col_x, row_y, word_map):
	"""
	Infer horizontal and vertical text alignment from:
	  - cell_bbox  : full cell extents derived from the grid lines (col_x, row_y)
	  - content_bbox: the tight polygon Azure fitted around the cell's text

	Horizontal centering: space_left ≈ space_right
	  - Uses ratio test: |space_left - space_right| / cell_width < 0.15
	  - AND both spaces must be > 5 % of cell_width (avoids near-full cells)
	Right align: space_left > space_right by > 15 % of cell_width AND space_left > 5 %

	Vertical centering: space_top ≈ space_bottom
	  - Uses ratio test: |space_top - space_bottom| / cell_height < 0.20
	  - No min_space guard (cells can be tightly packed vertically)
	"""
	horiz = WD_ALIGN_PARAGRAPH.LEFT
	vert  = WD_ALIGN_VERTICAL.TOP

	if not detect_horiz_alig_text_in_table and not detect_vert_alig_text_in_table:
		return horiz, vert

	try:
		ci = cell.column_index
		cs = cell.column_span or 1
		ri = cell.row_index
		rs = cell.row_span or 1

		cell_left   = col_x[ci]
		cell_right  = col_x[ci + cs]
		cell_top    = row_y[ri]
		cell_bottom = row_y[ri + rs]
		cell_width  = cell_right  - cell_left
		cell_height = cell_bottom - cell_top

		if cell_width <= 0 or cell_height <= 0:
			return horiz, vert

		# Content bbox = tight box around actual words in this cell (via span lookup)
		content = get_content_bbox_from_words(cell, word_map)
		if content is None:
			return horiz, vert
		cont_left, cont_right, cont_top, cont_bottom = content

		space_left   = cont_left   - cell_left
		space_right  = cell_right  - cont_right
		space_top    = cont_top    - cell_top
		space_bottom = cell_bottom - cont_bottom

		# Horizontal alignment
		if detect_horiz_alig_text_in_table:
			tol_h       = cell_width * horiz_align_sensitivity
			min_space_h = cell_width * (horiz_align_sensitivity / 3.0)
			if (space_left >= min_space_h and space_right >= min_space_h
					and abs(space_left - space_right) <= tol_h):
				horiz = WD_ALIGN_PARAGRAPH.CENTER
			elif space_left > space_right + tol_h and space_left >= min_space_h:
				horiz = WD_ALIGN_PARAGRAPH.RIGHT

		# Vertical alignment
		# Tolerance is scaled by row_span: merged cells have more whitespace
		# around text relative to the full merged height, so need a looser tol.
		if detect_vert_alig_text_in_table:
			tol_v = cell_height * min(vert_align_sensitivity * rs, 0.35)
			if abs(space_top - space_bottom) <= tol_v:
				vert = WD_ALIGN_VERTICAL.CENTER
			elif space_top > space_bottom + tol_v:
				vert = WD_ALIGN_VERTICAL.BOTTOM

	except Exception:
		pass

	return horiz, vert


def clean_text(text):
	# Remove :selected: and :unselected:, case-insensitive and with optional whitespace
	text = re.sub(r':(?:un)?selected:|:checked:|:yes:', '', text, flags=re.IGNORECASE).strip()
	
	# Replace middle dot with hyphen if it's at the start of the text
	# This handles cases where '·' is the first character of the paragraph or cell
	text = re.sub(r'^·', '-', text)
	return text
	
# Helper function
def extract_span_text(span, full_text):
	return full_text[span.offset : span.offset + span.length]

print(intMax,"files total:")

for singleFile in dirWithFiles:
	singleFileWithPath = os.path.join(indir, singleFile)
	intCounter += 1
	print(f'Ocr of file {intCounter} of {intMax} ({round(intCounter/intMax*100, 2)}%): {singleFile}')


	with open(singleFileWithPath, "rb") as fileInsideWithLoop:
		image_data = fileInsideWithLoop.read()

		client = DocumentIntelligenceClient(endpoint=endpoint, credential=AzureKeyCredential(key))

		poller = client.begin_analyze_document(st_model, image_data)
		result = poller.result()

		if save_azure_output:
			azure_json_path = os.path.splitext(singleFileWithPath)[0] + '.azure.json'
			with open(azure_json_path, 'w', encoding='utf-8') as fj:
				json.dump(result.as_dict(), fj, ensure_ascii=False, indent=2)
			print(f'  Azure output saved: {azure_json_path}')
		
		page_text = reconstruct_lines_from_words(result)
		full_text_in_lines += page_text


		used_span_offsets = set()
		full_text = result.content

		# Step 1: Preprocess Tables
		blocks_with_spans = []

		if st_model!='prebuilt-read':#no tables in prebuit-red, yes in prebuilt-layout and other more expensive ones
			for table in result.tables:
				if table.spans:
					blocks_with_spans.append({
						"type": "table",
						"span_offset": table.spans[0].offset,
						"table": table
					})

					for cell in table.cells:
						for span in cell.spans:
							used_span_offsets.add(span.offset)

		# Step 2: Add Paragraphs
		for paragraph in result.paragraphs:
			if paragraph.spans:
				para_text = ""
				new_spans_used = False

				for span in paragraph.spans:
					if span.offset not in used_span_offsets:
						para_text += clean_text(extract_span_text(span, full_text))
						used_span_offsets.add(span.offset)
						new_spans_used = True

				if new_spans_used and para_text.strip():
					raw_text = extract_span_text(paragraph.spans[0], full_text).lstrip()
					is_list = (
						getattr(paragraph, "role", None) == "listItem"
						or raw_text.startswith("·")
						or raw_text.startswith("• ")
					)
					blocks_with_spans.append({
						"type": "paragraph",
						"span_offset": paragraph.spans[0].offset,
						"content": para_text.strip(),
						"role": getattr(paragraph, "role", None),
						"is_list": is_list
					})

		# Step 3: Sort by reading order
		blocks_with_spans.sort(key=lambda b: b["span_offset"])

		# Step 4: Write content to the shared document
		for i, block in enumerate(blocks_with_spans):
			if block["type"] == "paragraph":
				#doc.add_paragraph(block["content"]) #use this if no justify
				
				para = doc.add_paragraph(block["content"])#use this if modifying content instead of doc.add_p ...
				para.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY#use this if justify
				#para.paragraph_format.space_before = Pt(0)#no space before/after paragraph
				#para.paragraph_format.space_after = Pt(0) 
				
				# Add blank line after non-list paragraphs, and after the LAST item of a list run
				is_list = block.get("is_list", False)
				next_block = blocks_with_spans[i + 1] if i + 1 < len(blocks_with_spans) else None
				next_is_list = next_block.get("is_list", False) if next_block and next_block["type"] == "paragraph" else False
				if not is_list or (is_list and not next_is_list):
					doc.add_paragraph("\u00A0")

			elif block["type"] == "table":
				table_data = block["table"]
				max_row_idx = 0
				max_col_idx = 0

				# First pass: find table dimensions
				for cell in table_data.cells:
					max_row_idx = max(max_row_idx, cell.row_index + (cell.row_span or 1) - 1)
					max_col_idx = max(max_col_idx, cell.column_index + (cell.column_span or 1) - 1)

				num_cols = max_col_idx + 1
				num_rows = max_row_idx + 1

				# Build grid lines in raw Azure units (pixels when unit="pixel",
				# inches when unit="inch"). We scale to docx inches using the table
				# bounding box mapped to the docx content width.
				col_x, row_y = build_grid_lines(table_data, num_cols, num_rows)

				# docx content width = page width - left margin - right margin.
				# This is the writable area width and matches how paragraph text lays out.
				docx_content_w_in = (section.page_width - section.left_margin - section.right_margin) / 914400  # EMU→inch

				# Compute pixel scale: map source table pixel width → target docx width.
				# When table_width_is_page_width=1, target = full content width so the
				# table always spans edge-to-edge of the writable area, just like paragraphs.
				# When 0, target = proportional to the content width (original behaviour).
				table_bbox = get_cell_bbox(table_data) if hasattr(table_data, 'bounding_regions') else None
				if table_bbox:
					table_px_w = table_bbox[1] - table_bbox[0]  # right - left
				else:
					table_px_w = col_x[-1] - col_x[0] if col_x[-1] and col_x[0] else 1
				px_scale = docx_content_w_in / table_px_w if table_px_w > 0 else 1.0

				# Column widths in inches from grid lines
				if detect_column_width_table:
					resolved_col = [(col_x[i + 1] - col_x[i]) * px_scale for i in range(num_cols)]
					# Safety: clamp to minimum 0.2 inch
					resolved_col = [max(w, 0.2) for w in resolved_col]
					# If table_width_is_page_width, rescale columns so they sum exactly
					# to docx_content_w_in (handles rounding and clamping drift).
					if table_width_is_page_width:
						col_total = sum(resolved_col)
						if col_total > 0:
							resolved_col = [w * docx_content_w_in / col_total for w in resolved_col]

				# Row heights in inches from grid lines
				if detect_row_height_table:
					resolved_row = [(row_y[i + 1] - row_y[i]) * px_scale for i in range(num_rows)]
					# Safety: clamp to minimum 0.1 inch
					resolved_row = [max(h, 0.1) for h in resolved_row]

				# Build word map for alignment detection (word offset -> pixel bbox)
				word_map = build_word_map(result)

				docx_table = doc.add_table(rows=num_rows, cols=num_cols)
				docx_table.style = "Table Grid"  # <-- This adds borders

				# Set table width, indent, and layout on tblPr.
				# Three elements are needed together:
				#   tblW  - total table width in twips
				#   tblInd=0 - pins left edge to the left margin (no residual indent)
				#   tblLayout fixed - tells Word/LibreOffice to honour explicit widths
				#                     instead of auto-sizing columns by content
				# Element order in tblPr matters for schema compliance:
				#   tblStyle → tblW → tblInd → tblLayout → tblLook
				tbl    = docx_table._tbl
				tblPr  = tbl.find(qn('w:tblPr'))
				if tblPr is None:
					tblPr = OxmlElement('w:tblPr')
					tbl.insert(0, tblPr)
				# Remove any existing tblW / tblInd / tblLayout so we fully control them
				for tag in ('w:tblW', 'w:tblInd', 'w:tblLayout'):
					el = tblPr.find(qn(tag))
					if el is not None:
						tblPr.remove(el)
				# Insert in correct schema order, anchored after tblStyle
				tblStyle = tblPr.find(qn('w:tblStyle'))
				anchor   = tblStyle if tblStyle is not None else tblPr
				tblW = OxmlElement('w:tblW')
				if table_width_is_page_width:
					# type='pct' w='5000' = 100% of the content area.
					# Dynamically fills available width regardless of margin changes.
					tblW.set(qn('w:w'), '5000')
					tblW.set(qn('w:type'), 'pct')
				else:
					# Fixed width in twips based on current margin settings
					tbl_w_twips = int(sum(resolved_col) * 1440) if detect_column_width_table else int(docx_content_w_in * 1440)
					tblW.set(qn('w:w'), str(tbl_w_twips))
					tblW.set(qn('w:type'), 'dxa')
				anchor.addnext(tblW)
				tblInd = OxmlElement('w:tblInd')
				tblInd.set(qn('w:w'), '0')
				tblInd.set(qn('w:type'), 'dxa')
				tblW.addnext(tblInd)
				tblLayout = OxmlElement('w:tblLayout')
				tblLayout.set(qn('w:type'), 'fixed')
				tblInd.addnext(tblLayout)

				# Apply column widths.
				# Must set BOTH the tblGrid gridCol elements (which Word uses as the
				# authoritative column width) AND each cell's tcW — setting only tcW
				# leaves the tblGrid at equal widths and Word ignores the cell values.
				if detect_column_width_table:
					# 1. Rewrite tblGrid gridCol widths
					tbl = docx_table._tbl
					tblGrid = tbl.find(qn('w:tblGrid'))
					if tblGrid is None:
						tblGrid = OxmlElement('w:tblGrid')
						tbl.insert(0, tblGrid)
					# Remove existing gridCol elements and replace with correct widths
					for gc in tblGrid.findall(qn('w:gridCol')):
						tblGrid.remove(gc)
					for width_in in resolved_col:
						gc = OxmlElement('w:gridCol')
						gc.set(qn('w:w'), str(int(width_in * 1440)))
						tblGrid.append(gc)
					# 2. Also set tcW on every cell so merged cells stay consistent
					for col_idx, width_in in enumerate(resolved_col):
						for row_idx in range(num_rows):
							docx_table.cell(row_idx, col_idx).width = Inches(width_in)

				# Apply row heights via the trPr/trHeight XML element.
				# python-docx has no built-in API for row height so we set it directly.
				if detect_row_height_table:
					for row_idx, height_in in enumerate(resolved_row):
						tr = docx_table.rows[row_idx]._tr
						trPr = tr.find(qn('w:trPr'))
						if trPr is None:
							trPr = OxmlElement('w:trPr')
							tr.insert(0, trPr)
						trHeight = trPr.find(qn('w:trHeight'))
						if trHeight is None:
							trHeight = OxmlElement('w:trHeight')
							trPr.append(trHeight)
						# hRule="atLeast" lets the row grow if content overflows
						twips = int(height_in * 1440)
						trHeight.set(qn('w:val'), str(twips))
						trHeight.set(qn('w:hRule'), 'atLeast')

				# Second pass: fill text, apply merges, and set alignment
				for cell in table_data.cells:
					row_idx = cell.row_index
					col_idx = cell.column_index
					row_span = cell.row_span or 1
					col_span = cell.column_span or 1

					cell_text = ""
					for span in cell.spans:
						cell_text += clean_text(extract_span_text(span, full_text))
					cell_text = cell_text.strip()

					# Get the top-left cell of this merged region
					docx_cell = docx_table.cell(row_idx, col_idx)

					# Apply merge if spanning multiple rows or columns
					if row_span > 1 or col_span > 1:
						end_cell = docx_table.cell(
							row_idx + row_span - 1,
							col_idx + col_span - 1
						)
						docx_cell = docx_cell.merge(end_cell)

					# Infer and apply alignment using grid-derived cell boundaries
					horiz_align, vert_align = infer_cell_alignment(cell, col_x, row_y, word_map)
					docx_cell.vertical_alignment = vert_align
					docx_cell.text = cell_text
					for para in docx_cell.paragraphs:
						para.alignment = horiz_align

				#add newline after table
				doc.add_paragraph("\u00A0")

		# Optional: Add a page break after each file
		#doc.add_page_break()
		
		#no need for two newlines
		#doc.add_paragraph("\u00A0")
		doc.add_paragraph("\u00A0")
		
		#print('waiting ... ',pause_time )
		#time.sleep(pause_time)

# Save the final combined document

print('OCR complete')

doc.save(output_docx_path)
print('Output file saved as docx:', output_docx_path)

with open(txt_output_path, "w", encoding="utf-8") as f:
	f.write(full_text_in_lines)
print ('(Output file saved as text in case you need it, tables NOT present, extra newlines NOT removed:', txt_output_path,')')
