
#2026-02-24-3

r'''

to install on windows:
pip install -U azure-ai-documentintelligence
pip install -U python-docx

copy pdf to ocr folder.
start bat file.


on linux debian:
if not installed install python3: 
sudo apt-get install python3

install 'python3-pip', which will be later used as just 'pip': 
sudo apt install python3-pip

and finally, use '--break-system-packages' option to be allowed to install system wide packages, using just 'pip':
pip install --break-system-packages -U azure-ai-documentintelligence
pip install --break-system-packages -U python-docx

install poppler for your distro.

copy pdf to ocr folder.
start sh file.

program will ocr files saved in 'ocr' folder, and save result in ocr.text, utf-8 encoded.
on windows, put images in ocr folder, and start program by double clicking on 'azure_ocr.bat'
you can use ghostscript to conver pdf to images: 
gs\bin\gswin32c.exe -sCompression=pack -dTextAlphaBits=4 -dGraphicsAlphaBits=4  -sDEVICE=tiffgray -r300 -o output-%03d.tif input.pdf
use output-%%03d.tif if running inside bat file.

or xpdf:
xpdf\pdftopng.exe -r 300 -gray  source destination

'''

#https://learn.microsoft.com/en-us/azure/ai-services/document-intelligence/quickstarts/get-started-sdks-rest-api?view=doc-intel-4.0.0&preserve-view=true&pivots=programming-language-python
#create document inteligence resource: north eu, free
#enter key and endpoint

#https://github.com/Azure-Samples/document-intelligence-code-samples/tree/main
#https://github.com/Azure-Samples/document-intelligence-code-samples/blob/main/Python(v4.0)/Layout_model/sample_analyze_layout.py


key = ""
endpoint = ""

st_model="prebuilt-read" #cheaper, no tables; 1000 pages=$1.5
#uncomment line below to detect tables
st_model="prebuilt-layout" #more expensive, tables; 1000 pages=$10
print('using', st_model, 'model')


import os
import time
import re
from azure.core.credentials import AzureKeyCredential
from azure.ai.documentintelligence import DocumentIntelligenceClient
from azure.ai.documentintelligence.models import AnalyzeResult
from azure.ai.documentintelligence.models import AnalyzeDocumentRequest
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt
from io import BytesIO
from docx.shared import Mm
import sys


if key == "" or endpoint == "":
	print("FATAL ERROR: missing key or endpoint variables.")
	input("Press Enter to exit...")
	sys.exit()

indir = 'ocr'

if not os.path.isdir(indir):
	print('Please pass *existing* directory name')
	exit()

dirWithFiles = os.listdir(indir)
dirWithFiles.sort()


intCounter = 0
intMax = len(dirWithFiles)
output_docx_path = "output_"+ st_model + ".docx"
txt_output_path = os.path.splitext(output_docx_path)[0] + "-lines-mode.txt"
full_text_in_lines = ''

if os.path.exists(output_docx_path):
	os.remove(output_docx_path)

if os.path.exists(txt_output_path):
	os.remove(txt_output_path)

# Create ONE Word document to append to

doc = Document()
#a4, margins
section = doc.sections[0]
section.page_height = Mm(297)
section.page_width = Mm(210)
section.left_margin = Mm(25.4)
section.right_margin = Mm(25.4)
section.top_margin = Mm(25.4)
section.bottom_margin = Mm(25.4)
section.header_distance = Mm(12.7)
section.footer_distance = Mm(12.7)


#no auto space after para
style = doc.styles['Normal']
style.paragraph_format.space_after = Pt(0)
style.paragraph_format.space_before = Pt(0)
#style.paragraph_format.line_spacing = Pt(12)  # Optional: control line spacing

# Access the font object of the 'Normal' style
font = style.font
# Set the desired font name and size
font.name = 'Times New Roman'  # Example: Set font to Arial
#font.name = 'Calibri'
font.size = Pt(12)   # Example: Set font size to 12 points




def reconstruct_lines_from_words(result, y_bucket_threshold=10):
	all_words = []

	for page in result.pages:
		for word in page.words:
			if word.content.strip() and word.polygon:
				coords = word.polygon
				x_coords = coords[0::2]
				y_coords = coords[1::2]

				x_min = min(x_coords)
				x_max = max(x_coords)
				y_min = min(y_coords)
				y_max = max(y_coords)
				y_center = (y_min + y_max) / 2

				all_words.append({
					"text": clean_text(word.content),
					"x_min": x_min,
					"x_max": x_max,
					"y_center": y_center
				})

	# Step 1: Bucket words by y_center into lines
	lines = []
	for word in sorted(all_words, key=lambda w: w["y_center"]):
		placed = False
		for line in lines:
			if abs(word["y_center"] - line["y_center"]) <= y_bucket_threshold:
				line["words"].append(word)
				line["y_center"] = (line["y_center"] * len(line["words"]) + word["y_center"]) / (len(line["words"]) + 1)
				placed = True
				break
		if not placed:
			lines.append({
				"y_center": word["y_center"],
				"words": [word]
			})

	# Step 2: Sort words in each line left to right
	for line in lines:
		line["words"].sort(key=lambda w: w["x_min"])

	# Step 3: Sort lines top to bottom
	lines.sort(key=lambda l: l["y_center"])

	# Step 4: Write to file
	text_output = ""
	for line in lines:
		line_text = " ".join(w["text"] for w in line["words"])
		text_output += line_text.strip() + "\n"
	text_output += "\n"

	return text_output





def clean_text(text):
	# Remove :selected: and :unselected:, case-insensitive and with optional whitespace
	return re.sub(r':(?:un)?selected:|:checked:|:yes:', '', text, flags=re.IGNORECASE).strip()
	
# Helper function
def extract_span_text(span, full_text):
	return full_text[span.offset : span.offset + span.length]

print(intMax,"files total:")

for singleFile in dirWithFiles:
	singleFileWithPath = os.path.join(indir, singleFile)
	intCounter += 1
	print(f'Ocr of file {intCounter} of {intMax} ({round(intCounter/intMax*100, 2)}%): {singleFile}')


	with open(singleFileWithPath, "rb") as fileInsideWithLoop:
		image_data = fileInsideWithLoop.read()

		client = DocumentIntelligenceClient(endpoint=endpoint, credential=AzureKeyCredential(key))

		poller = client.begin_analyze_document(st_model, image_data)
		result = poller.result()
		
		page_text = reconstruct_lines_from_words(result)
		full_text_in_lines += page_text


		used_span_offsets = set()
		full_text = result.content

		# Step 1: Preprocess Tables
		blocks_with_spans = []

		if st_model!='prebuilt-read':#no tables in prebuit-red, yes in prebuilt-layout and other more expensive ones
			for table in result.tables:
				if table.spans:
					blocks_with_spans.append({
						"type": "table",
						"span_offset": table.spans[0].offset,
						"table": table
					})

					for cell in table.cells:
						for span in cell.spans:
							used_span_offsets.add(span.offset)

		# Step 2: Add Paragraphs
		for paragraph in result.paragraphs:
			if paragraph.spans:
				para_text = ""
				new_spans_used = False

				for span in paragraph.spans:
					if span.offset not in used_span_offsets:
						para_text += clean_text(extract_span_text(span, full_text))
						used_span_offsets.add(span.offset)
						new_spans_used = True

				if new_spans_used and para_text.strip():
					blocks_with_spans.append({
						"type": "paragraph",
						"span_offset": paragraph.spans[0].offset,
						"content": para_text.strip()
					})

		# Step 3: Sort by reading order
		blocks_with_spans.sort(key=lambda b: b["span_offset"])

		# Step 4: Write content to the shared document
		for block in blocks_with_spans:
			if block["type"] == "paragraph":
				#doc.add_paragraph(block["content"]) #use this if no justify
				
				para = doc.add_paragraph(block["content"])#use this if modifying content instead of doc.add_p ...
				para.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY#use this if justify
				#para.paragraph_format.space_before = Pt(0)#no space before/after paragraph
				#para.paragraph_format.space_after = Pt(0) 
				
				#add space after each paragraph
				doc.add_paragraph("\u00A0")

			elif block["type"] == "table":
				table_data = block["table"]
				cell_map = {}
				max_row_idx = 0
				max_col_idx = 0

				for cell in table_data.cells:
					row_idx = cell.row_index
					col_idx = cell.column_index

					max_row_idx = max(max_row_idx, row_idx)
					max_col_idx = max(max_col_idx, col_idx)

					cell_text = ""
					for span in cell.spans:
						cell_text += clean_text(extract_span_text(span, full_text))

					cell_map[(row_idx, col_idx)] = cell_text.strip()

				docx_table = doc.add_table(rows=max_row_idx + 1, cols=max_col_idx + 1)
				docx_table.style = "Table Grid"  # <-- This adds borders

				for (row_idx, col_idx), text in cell_map.items():
					docx_table.cell(row_idx, col_idx).text = text
				
				#add newline after table
				doc.add_paragraph("\u00A0")

		# Optional: Add a page break after each file
		#doc.add_page_break()
		
		#doc.add_paragraph("\u00A0")
		doc.add_paragraph("\u00A0")
		
		#print('waiting ... ',pause_time )
		#time.sleep(pause_time)

# Save the final combined document

print('OCR complete')

doc.save(output_docx_path)
print('Output file saved as docx:', output_docx_path)

with open(txt_output_path, "w", encoding="utf-8") as f:
	f.write(full_text_in_lines)
print ('(Output file saved as text in case you need it, tables NOT present, extra newlines NOT removed:', txt_output_path,')')
