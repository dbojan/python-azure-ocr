
#2025-12-29-1

r'''
to install on windows:
pip install -U azure.ai.vision.imageanalysis
or just
pip install azure.ai.vision.imageanalysis

copy pdf to ocr folder.
start bat file.


on linux debian:
if not installed install python3: 
sudo apt-get install python3

install 'python3-pip', which will be later used as just 'pip': 
sudo apt install python3-pip

and finally, use '--break-system-packages' option to be allowed to install system wide packages, using just 'pip':
pip install --break-system-packages -U azure.ai.vision.imageanalysis

install poppler for your distro.

copy pdf to ocr folder.
start sh file.

program will ocr files saved in 'ocr' folder, and save result in ocr.text, utf-8 encoded.
on windows, put images in ocr folder, and start program by double clicking on 'azure_ocr.bat'
you can use ghostscript to conver pdf to images: 
gs\bin\gswin32c.exe -sCompression=pack -dTextAlphaBits=4 -dGraphicsAlphaBits=4  -sDEVICE=tiffgray -r300 -o output-%03d.tif input.pdf
use output-%%03d.tif if running inside bat file.

or xpdf:
xpdf\pdftopng.exe -r 300 -gray  source destination

'''

#https://learn.microsoft.com/en-us/azure/ai-services/computer-vision/quickstarts-sdk/image-analysis-client-library-40?tabs=visual-studio%2Cwindows&pivots=programming-language-python
#https://learn.microsoft.com/en-us/python/api/overview/azure/ai-vision-imageanalysis-readme?view=azure-python-preview

#c sharp
#https://learn.microsoft.com/en-us/dotnet/api/overview/azure/ai.vision.imageanalysis-readme?view=azure-dotnet-preview


key = ""
endpoint = ""

import os
import time
from azure.core.credentials import AzureKeyCredential
from azure.ai.vision.imageanalysis import ImageAnalysisClient
from azure.ai.vision.imageanalysis.models import VisualFeatures

import json#fn_no_colums
import ast#fn_no_colums


if key == "" or endpoint == "":
	print("FATAL ERROR: missing key or endpoint variables.")
	input("Press Enter to exit...")
	sys.exit()

# Create an Image Analysis client
client = ImageAnalysisClient(
	endpoint=endpoint,
	credential=AzureKeyCredential(key)
)

indir = 'ocr'

if not os.path.isdir(indir):
	print('Please pass *existing* directory name')
	exit()

dirWithFiles = os.listdir(indir)
dirWithFiles.sort()

#for azr free tier, max 20 per minute. png, tif, jpg accepted. 
#for free tier tiff only first 1 page ocred. 4s for 1s extra time, to be sure it keeps going


intNumberOfFIles = len(dirWithFiles)
if intNumberOfFIles > 20:
	pause_time = 4
else:
	pause_time = 0

buffer = ""
ocrtext = ""
nc_text = "" #no columns detected
print (dirWithFiles)

txt_in_output_text = ''

outOcrFile = indir + "-out_Ocr_File.txt"
outBufferFile = indir + "-out_Ocr_BufferFile.txt"
outNoColumnFile = indir + "-out_Ocr_NoColumnFile.txt"

out_txt_in_File = indir + "-out_txt_in_File.txt"

if os.path.exists(outOcrFile):
	os.remove(outOcrFile)
	
if os.path.exists(outBufferFile):
	os.remove(outBufferFile)

if os.path.exists(outNoColumnFile):
	os.remove(outNoColumnFile)


intCounter = 0
intMax = len(dirWithFiles)


def fn_no_colums(data):
    text = ''
    prev_right_x = -1
    prev_bottom_y = -1
    
    # Flatten all lines from all blocks into one list
    all_lines = []
    for block in data['blocks']:
        for line in block['lines']:
            all_lines.append(line)

    for line_data in all_lines:
        word = line_data['text']
        poly = line_data['boundingPolygon']
        
        # current coordinates
        curr_left_x = poly[0]['x']
        curr_right_x = poly[1]['x']
        curr_top_y = poly[0]['y']
        curr_bottom_y = poly[2]['y']
        
        # Calculate a vertical center or use a threshold
        # If the top of the new word is higher than the bottom of the old word, 
        # but not TOO much higher, it's likely the same line.
        
        # We use a 10-pixel tolerance for "same line" detection
        vertical_threshold = 10 
        
        if prev_right_x == -1:
            # First line of the document
            text = word
        elif curr_top_y > (prev_bottom_y - vertical_threshold) and curr_left_x >= (prev_right_x - 5):
            # Same line: The new word starts after the old one and is vertically similar
            text = text + ' ' + word
        else:
            # New line: Either it's physically lower or it jumped back to the left
            text = text + '\n' + word

        # Update trackers for the next iteration
        prev_right_x = curr_right_x
        prev_bottom_y = curr_bottom_y

    return text



newline_text = ''

for singleFile in dirWithFiles:
	singleFileWithPath = os.path.join(indir, singleFile)
	intCounter = intCounter + 1
	print('File ' + str(intCounter) + ' of ' + str(intMax) + ' (' + str( round(intCounter/intMax*100,2) ) +  '%): ' + singleFile ) #always inside folder, so no need for ..withPath

	if singleFile.rsplit('.', 1)[1] == 'txt': #find ext
		print (singleFile,'txt ? ... ')
		with open(singleFileWithPath, 'r', encoding="utf-8") as file:
			wholetext = file.read()
			wholeTextLines = wholetext.splitlines()
			for i in range (len(wholeTextLines)):
				line = wholeTextLines[i]
				if line.startswith("{'blocks': [{'lines': [{'text': "):
					txt_in_output_text = txt_in_output_text + newline_text + fn_no_colums(   ast.literal_eval( str(line) )   )
					newline_text = '\n\n'
		continue

	with open(singleFileWithPath, "rb") as fileInsideWithLoop:
		image_data = fileInsideWithLoop.read()
		result = client.analyze(
			image_data=image_data,
			visual_features=[VisualFeatures.READ])
			
		#print(result)

		if result.read is not None:
			#print (type(result.read.blocks))
			#print ( len(result.read.blocks) )
			if len(result.read.blocks) > 0:#just an image, no text, dont add buffer to text list if empty

				nc_text = nc_text + fn_no_colums(   ast.literal_eval( str(result.read) )   ) + '\n\n'

				buffer += str(result.read)+'\n\n' 
				for line in result.read.blocks[0].lines:
					ocrtext += line.text+'\n'
				ocrtext = ocrtext+'\n'
				
				#in case of interruption or error, use temp files, but only if there are a lot of files
				if intNumberOfFIles > 10:
					with open(outBufferFile+'_temp.txt', "w", encoding="utf-8") as fileBufferInsideWithLoop:
						fileBufferInsideWithLoop.write(buffer)
						
					with open(outOcrFile+'_temp.txt', "w", encoding="utf-8") as fileOutputInsideWithLoop:
						fileOutputInsideWithLoop.write(ocrtext)

			else:
				print("just an image, no text?")
			
		else:
			print(fileInsideWithLoop, 'No data returned, exiting')
			exit()
		
		time.sleep(pause_time)
		
with open(outBufferFile, "w", encoding="utf-8") as fileBufferInsideWithLoop:
	fileBufferInsideWithLoop.write(buffer)

with open(outOcrFile, "w", encoding="utf-8") as fileOutputInsideWithLoop:
	fileOutputInsideWithLoop.write(ocrtext)
	
with open(outNoColumnFile, "w", encoding="utf-8") as fileHolder_outNoColumnFile:
	fileHolder_outNoColumnFile.write(nc_text)


if txt_in_output_text:
	with open(out_txt_in_File, "w", encoding="utf-8") as fileHolder_out_txt_in_File:
		fileHolder_out_txt_in_File.write(txt_in_output_text)
	
