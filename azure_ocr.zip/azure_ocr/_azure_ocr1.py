

#2026-02-06-1

r'''
to install on windows:
pip install -U azure.ai.vision.imageanalysis
or just
pip install azure.ai.vision.imageanalysis

copy pdf to ocr folder.
start bat file.

on linux debian:
if not installed install python3: 
sudo apt-get install python3

install 'python3-pip', which will be later used as just 'pip': 
sudo apt install python3-pip

and finally, use '--break-system-packages' option to be allowed to install system wide packages, using just 'pip':
pip install --break-system-packages -U azure.ai.vision.imageanalysis

install poppler for your distro.

copy pdf to ocr folder.
start sh file.

program will ocr files saved in 'ocr' folder, and save result in ocr.text, utf-8 encoded.
on windows, put images in ocr folder, and start program by double clicking on 'azure_ocr.bat'
you can use ghostscript to conver pdf to images: 
gs\bin\gswin32c.exe -sCompression=pack -dTextAlphaBits=4 -dGraphicsAlphaBits=4  -sDEVICE=tiffgray -r300 -o output-%03d.tif input.pdf
use output-%%03d.tif if running inside bat file.

or xpdf:
xpdf\pdftopng.exe -r 300 -gray  source destination

'''

#https://learn.microsoft.com/en-us/azure/ai-services/computer-vision/quickstarts-sdk/image-analysis-client-library-40?tabs=visual-studio%2Cwindows&pivots=programming-language-python
#https://learn.microsoft.com/en-us/python/api/overview/azure/ai-vision-imageanalysis-readme?view=azure-python-preview

#c sharp
#https://learn.microsoft.com/en-us/dotnet/api/overview/azure/ai.vision.imageanalysis-readme?view=azure-dotnet-preview


import os,json
from azure.ai.vision.imageanalysis import ImageAnalysisClient
from azure.ai.vision.imageanalysis.models import VisualFeatures
from azure.core.credentials import AzureKeyCredential

# Replace with your Azure Vision endpoint and key

key = ""
endpoint = ""


client = ImageAnalysisClient(endpoint=endpoint, credential=AzureKeyCredential(key))

image_folder = "ocr"
#text_output = "ocr_output.txt"
#text_output = image_folder + "-out_Ocr_File.txt"
text_output = image_folder + "-out_Ocr_NoColumnFile.txt"
coords_output = "ocr_words.json"

def polygon_to_list(polygon):
    """Convert list of ImagePoint objects to list of [x, y] pairs."""
    return [[p.x, p.y] for p in polygon]

def reconstruct_from_words(words, y_threshold=5):
    """
    Rebuild text lines from words using vertical overlap clustering.
    """
    # Convert words into (text, avg_x, avg_y, polygon)
    word_data = []
    for w in words:
        avg_x = sum([p.x for p in w.bounding_polygon]) / len(w.bounding_polygon)
        avg_y = sum([p.y for p in w.bounding_polygon]) / len(w.bounding_polygon)
        word_data.append((w.text, avg_x, avg_y, w.bounding_polygon))

    # Sort by y first
    word_data.sort(key=lambda x: (x[2], x[1]))

    lines = []
    current_line = []
    last_y = None

    for text, avg_x, avg_y, poly in word_data:
        if last_y is None or abs(avg_y - last_y) < y_threshold:
            current_line.append((text, avg_x, avg_y, poly))
            last_y = avg_y
        else:
            # Sort current line by x
            current_line.sort(key=lambda x: x[1])
            lines.append(current_line)
            current_line = [(text, avg_x, avg_y, poly)]
            last_y = avg_y

    if current_line:
        current_line.sort(key=lambda x: x[1])
        lines.append(current_line)

    # Convert to text lines
    reconstructed = []
    for line in lines:
        line_text = " ".join([w[0] for w in line])
        reconstructed.append(line_text)

    return reconstructed


all_results = {}

with open(text_output, "w", encoding="utf-8") as text_out:
    for filename in sorted( os.listdir(image_folder) ):
        if filename.lower().endswith((".png", ".jpg", ".jpeg", ".bmp", ".tiff", ".tif")):
            image_path = os.path.join(image_folder, filename)
            print(f"Processing {image_path}...")

            with open(image_path, "rb") as f:
                image_data = f.read()

            result = client.analyze(
                image_data=image_data,
                visual_features=[VisualFeatures.READ]
            )

            if result.read is not None and result.read.blocks:
                # Collect all words across blocks
                all_words = []
                for block in result.read.blocks:
                    for line in block.lines:
                        all_words.extend(line.words)

                # Reconstruct text purely from words
                reconstructed_lines = reconstruct_from_words(all_words)

                text_out.write("\n")
                #text_out.write(f"\n--- Text from {filename} ---\n")
                for line in reconstructed_lines:
                    text_out.write(line + "\n")

                # Save structured word info
                all_results[filename] = [
                    {"text": w.text, "polygon": polygon_to_list(w.bounding_polygon)}
                    for w in all_words
                ]
            else:
                text_out.write(f"\n--- No text detected in {filename} ---\n")

#with open(coords_output, "w", encoding="utf-8") as coords_out:
    #json.dump(all_results, coords_out, ensure_ascii=False, indent=2)

print(f"OCR complete. Text saved to {text_output}")
#, word coordinates saved to {coords_output}
