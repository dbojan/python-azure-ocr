
#2025-12-29-1

r'''
to install on windows:
pip install -U azure-ai-documentintelligence
pip install -U python-docx

copy pdf to ocr folder.
start bat file.


on linux debian:
if not installed install python3: 
sudo apt-get install python3

install 'python3-pip', which will be later used as just 'pip': 
sudo apt install python3-pip

and finally, use '--break-system-packages' option to be allowed to install system wide packages, using just 'pip':
pip install --break-system-packages -U azure-ai-documentintelligence
pip install --break-system-packages -U python-docx

install poppler for your distro.

copy pdf to ocr folder.
start sh file.

program will ocr files saved in 'ocr' folder, and save result in ocr.text, utf-8 encoded.
on windows, put images in ocr folder, and start program by double clicking on 'azure_ocr.bat'
you can use ghostscript to conver pdf to images: 
gs\bin\gswin32c.exe -sCompression=pack -dTextAlphaBits=4 -dGraphicsAlphaBits=4  -sDEVICE=tiffgray -r300 -o output-%03d.tif input.pdf
use output-%%03d.tif if running inside bat file.

or xpdf:
xpdf\pdftopng.exe -r 300 -gray  source destination

'''

#https://learn.microsoft.com/en-us/azure/ai-services/computer-vision/quickstarts-sdk/image-analysis-client-library-40?tabs=visual-studio%2Cwindows&pivots=programming-language-python
#https://learn.microsoft.com/en-us/python/api/overview/azure/ai-vision-imageanalysis-readme?view=azure-python-preview

#c sharp
#https://learn.microsoft.com/en-us/dotnet/api/overview/azure/ai.vision.imageanalysis-readme?view=azure-dotnet-preview


key = ""
endpoint = ""


import os
import time
from azure.core.credentials import AzureKeyCredential
from azure.ai.vision.imageanalysis import ImageAnalysisClient
from azure.ai.vision.imageanalysis.models import VisualFeatures

import json#fn_no_colums
import ast#fn_no_colums


if key == "" or endpoint == "":
	print("FATAL ERROR: missing key or endpoint variables.")
	input("Press Enter to exit...")
	sys.exit()

# Create an Image Analysis client
client = ImageAnalysisClient(
	endpoint=endpoint,
	credential=AzureKeyCredential(key)
)

indir = 'ocr'

if not os.path.isdir(indir):
	print('Please pass *existing* directory name')
	exit()

dirWithFiles = os.listdir(indir)
dirWithFiles.sort()

#for azr free tier, max 20 per minute. png, tif, jpg accepted. 
#for free tier tiff only first 1 page ocred. 4s for 1s extra time, to be sure it keeps going


intNumberOfFIles = len(dirWithFiles)
if intNumberOfFIles > 20:
	pause_time = 4
else:
	pause_time = 0

buffer = ""
ocrtext = ""
nc_text = "" #no columns detected
print (dirWithFiles)

txt_in_output_text = ''

outOcrFile = indir + "-out_Ocr_File.txt"
outBufferFile = indir + "-out_Ocr_BufferFile.txt"
outNoColumnFile = indir + "-out_Ocr_NoColumnFile.txt"

out_txt_in_File = indir + "-out_txt_in_File.txt"

if os.path.exists(outOcrFile):
    os.remove(outOcrFile)
	
if os.path.exists(outBufferFile):
    os.remove(outBufferFile)

if os.path.exists(outNoColumnFile):
    os.remove(outNoColumnFile)


intCounter = 0
intMax = len(dirWithFiles)



def fn_no_colums(data):
	text = ''

	for block in data['blocks']:
		prev_word_top_right_x = 0
		prev_word_top_left_x = 0
		prev_word_top_left_y = 0
		prev_word_bottom_right_y = 0
		for dc in block['lines']:
			#print('dc',dc)

			#print (type(dc['boundingPolygon']), dc['boundingPolygon'])
			#<class 'list'> [{'x': 12, 'y': 37}, {'x': 110, 'y': 39}, {'x': 109, 'y': 88}, {'x': 12, 'y': 87}]
							##top left(x,y) 0   ;top right(x,y) 1     ;bottom right(x,y) 2;  bottom left(x,y) 3

			##we need end of first word --> top right(x,y), so 1, not 0

			#print (type(dc['boundingPolygon'][1]['x']))#<class 'int'> 110

			word = dc['text']
			#print('word',word)
			current_word_top_left_x = dict(dc['boundingPolygon'][0])['x']#'current word' start(top left X coord)
			current_word_top_right_x = dict(dc['boundingPolygon'][1])['x']#'current word' end(top right X coord)

			current_word_top_left_y = dict(dc['boundingPolygon'][0])['y']
			current_word_bottom_right_y = dict(dc['boundingPolygon'][2])['y']

			#print(current_word_top_left_x,current_word_top_right_x,current_word_top_left_y,current_word_bottom_right_y)
			
			if prev_word_top_right_x==0:#starting, no text yet
				text = word
			elif prev_word_top_right_x > current_word_top_left_x  or current_word_top_left_y > prev_word_bottom_right_y:#other option is > prev bottom left, but it would be too much space between them, so we use prev bottom right. skewed pages?
				text = text + '\n' + word
			else:
				text = text + ' ' + word

			prev_word_top_right_x = current_word_top_right_x#move values to the previous word, think keyboard caps, with top left and top right corner, and hopping from one to the next
			prev_word_top_left_x = current_word_top_left_x
			prev_word_top_left_y = current_word_top_left_y
			prev_word_bottom_right_y = current_word_bottom_right_y

	return(text)



newline_text = ''

for singleFile in dirWithFiles:
	singleFileWithPath = os.path.join(indir, singleFile)
	intCounter = intCounter + 1
	print('File ' + str(intCounter) + ' of ' + str(intMax) + ' (' + str( round(intCounter/intMax*100,2) ) +  '%): ' + singleFile ) #always inside folder, so no need for ..withPath

	if singleFile.rsplit('.', 1)[1] == 'txt': #find ext
		print (singleFile,'txt ? ... ')
		with open(singleFileWithPath, 'r', encoding="utf-8") as file:
			wholetext = file.read()
			wholeTextLines = wholetext.splitlines()
			for i in range (len(wholeTextLines)):
				line = wholeTextLines[i]
				if line.startswith("{'blocks': [{'lines': [{'text': "):
					txt_in_output_text = txt_in_output_text + newline_text + fn_no_colums(   ast.literal_eval( str(line) )   )
					newline_text = '\n\n'
		continue

	with open(singleFileWithPath, "rb") as fileInsideWithLoop:
		image_data = fileInsideWithLoop.read()
		result = client.analyze(
			image_data=image_data,
			visual_features=[VisualFeatures.READ])
			
		#print(result)

		if result.read is not None:
			#print (type(result.read.blocks))
			#print ( len(result.read.blocks) )
			if len(result.read.blocks) > 0:#just an image, no text, dont add buffer to text list if empty

				nc_text = nc_text + fn_no_colums(   ast.literal_eval( str(result.read) )   ) + '\n\n'

				buffer += str(result.read)+'\n\n' 
				for line in result.read.blocks[0].lines:
					ocrtext += line.text+'\n'
				ocrtext = ocrtext+'\n'
				
				#in case of interruption or error, use temp files, but only if there are a lot of files
				if intNumberOfFIles > 10:
					with open(outBufferFile+'_temp.txt', "w", encoding="utf-8") as fileBufferInsideWithLoop:
						fileBufferInsideWithLoop.write(buffer)
						
					with open(outOcrFile+'_temp.txt', "w", encoding="utf-8") as fileOutputInsideWithLoop:
						fileOutputInsideWithLoop.write(ocrtext)

			else:
				print("just an image, no text?")
			
		else:
			print(fileInsideWithLoop, 'No data returned, exiting')
			exit()
		
		time.sleep(pause_time)
		
with open(outBufferFile, "w", encoding="utf-8") as fileBufferInsideWithLoop:
	fileBufferInsideWithLoop.write(buffer)

with open(outOcrFile, "w", encoding="utf-8") as fileOutputInsideWithLoop:
	fileOutputInsideWithLoop.write(ocrtext)
	
with open(outNoColumnFile, "w", encoding="utf-8") as fileHolder_outNoColumnFile:
	fileHolder_outNoColumnFile.write(nc_text)


if txt_in_output_text:
	with open(out_txt_in_File, "w", encoding="utf-8") as fileHolder_out_txt_in_File:
		fileHolder_out_txt_in_File.write(txt_in_output_text)
	