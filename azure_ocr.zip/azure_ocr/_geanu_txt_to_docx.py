
#2026-03-18-1


'''
SAVE FILE FIRST IN GEANY
to convert to docx:
In Geany, go to Build > Set Build Commands.
Build > Set Build Commands.
"Independent commands" or "Filetype commands" section.
label: 
docx
command: 
sh -c "python /home/b/data/p_azure_ocr/_geanu_txt_to_docx.py '%f' "

for convert to docx and mail:
In an empty slot under Independent commands, enter:
Label: 
Convert & Email
command: 
sh -c "python /home/b/data/p_azure_ocr/_geanu_txt_to_docx.py '%f' && /home/b/apps/betterbird/betterbird -compose \"subject='files',attachment='%p/%e.docx'\" "

to add to thunar 'send to betterbird':
edit/configure custom actions: 
/home/b/apps/betterbird/betterbird -compose "subject='Emailing: files',attachment=%F"

'''








import sys
import os
from docx import Document
from docx.shared import Pt, Mm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn

def convert_txt_to_docx(txt_file_path):
    # Check if file exists
    if not os.path.exists(txt_file_path):
        print(f"Error: File '{txt_file_path}' not found.")
        return

    # 1. Automatically generate output name: 'file.txt' -> 'file.docx'
    base_name = os.path.splitext(txt_file_path)[0]
    docx_file_path = f"{base_name}.docx"

    mydoc = Document()
    
    # Page Setup
    section = mydoc.sections[0]
    section.page_height, section.page_width = Mm(297), Mm(210)
    section.left_margin = section.right_margin = Mm(25.4)
    section.top_margin = section.bottom_margin = Mm(25.4)

    with open(txt_file_path, 'r', encoding='utf-8') as f:
        for line in f:
            clean_line = line.strip('\n\r')
            
            # Create paragraph with 0pt spacing
            p = mydoc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.space_before = Pt(0)
            p.paragraph_format.line_spacing = 1.0 
            
            # Add text and force 12pt Times New Roman
            run = p.add_run(clean_line)
            run.font.name = 'Times New Roman'
            run.font.size = Pt(12)
            
            # Fix for Word font recognition
            rFonts = run._element.rPr.get_or_add_rFonts()
            rFonts.set(qn('w:ascii'), 'Times New Roman')
            rFonts.set(qn('w:hAnsi'), 'Times New Roman')

    mydoc.save(docx_file_path)
    print(f"Successfully converted '{txt_file_path}' to '{docx_file_path}'")

if __name__ == "__main__":
    # 2. This part captures the filename you typed in the terminal
    if len(sys.argv) > 1:
        input_filename = sys.argv[1]
        convert_txt_to_docx(input_filename)
    else:
        print("Usage: python txt_to_docx.py <your_file.txt>")
