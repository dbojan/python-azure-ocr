python3 azure_ocr.py
read -rsp $'Press any key to continue ...\n' -n 1
