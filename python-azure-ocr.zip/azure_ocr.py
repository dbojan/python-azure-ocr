
#2024-05-18-1

'''
pip install azure-ai-vision-imageanalysis
'''

import os
import time
from azure.core.credentials import AzureKeyCredential
from azure.ai.vision.imageanalysis import ImageAnalysisClient
from azure.ai.vision.imageanalysis.models import VisualFeatures

try:
	endpoint = "ENTER YOUR ENDPOINT HERE"
	key = "ENTER YOU KEY HERE"
except KeyError:
	print("Missing environment variable 'VISION_ENDPOINT' or 'VISION_KEY'")
	print("Set them before running this sample.")
	exit()

# Create an Image Analysis client
client = ImageAnalysisClient(
	endpoint=endpoint,
	credential=AzureKeyCredential(key)
)

indir = 'ocr'

if not os.path.isdir(indir):
	print('Please pass *existing* directory name')
	exit()

dir1 = os.listdir(indir)
dir1.sort

#for azr free tier, max 20 per minute. png, tif, jpg accepted. 
#for free tier tiff only first 1 page ocred. 4s for 1s extra time, to be sure it keeps going

if len(dir1) > 20:
	pause_time = 4
else:
	pause_time = 0

buffer = ""
ocrtext = ""
print (dir1)

outocr = indir + "-ocrtext.txt"
outbuffer = indir + "-buffer.txt"

if os.path.exists(outocr):
    os.remove(outocr)
	
if os.path.exists(outbuffer):
    os.remove(outbuffer)

for f in dir1:
	f = os.path.join(indir, f)
	print(f)
	with open(f, "rb") as f:
		image_data = f.read()
		result = client.analyze(
			image_data=image_data,
			visual_features=[VisualFeatures.READ])

		if result.read is not None:
			buffer += str(result.read)+'\n\n'
			for line in result.read.blocks[0].lines:
				ocrtext += line.text+'\n'
			ocrtext = ocrtext+'\n'
			
		else:
			print(f, 'No data returned, exiting')
			exit()
		
		time.sleep(pause_time)
		
with open(outbuffer, "w", encoding="utf-8") as fb:
	fb.write(buffer)

with open(outocr, "w", encoding="utf-8") as fo:
	fo.write(ocrtext)
	