
#2024-06-26-1

'''
pip install azure-ai-vision-imageanalysis

on linux debian:
if not installed install python3: 
sudo apt-get install python3

install 'python3-pip', which will be later used as just 'pip': 
sudo apt install python3-pip

and finally, use '--break-system-packages' option to be allowed to install system wide packages, using just 'pip':
pip install azure-ai-vision-imageanalysis --break-system-packages

to start ocr, double click 'azure_ocr.py' in file manager
or start ocr program from command line: python3 azure_ocr.py 
or run azure_ocr.sh from terminal: ./azure_ocr.sh

'''

import os
import time
from azure.core.credentials import AzureKeyCredential
from azure.ai.vision.imageanalysis import ImageAnalysisClient
from azure.ai.vision.imageanalysis.models import VisualFeatures

try:
	endpoint = "https://ENTER ENDPOINT HERE"
	key = "ENTER KEY"
except KeyError:
	print("Missing environment variable 'VISION_ENDPOINT' or 'VISION_KEY'")
	print("Set them before running this sample.")
	exit()

# Create an Image Analysis client
client = ImageAnalysisClient(
	endpoint=endpoint,
	credential=AzureKeyCredential(key)
)

indir = 'ocr'

if not os.path.isdir(indir):
	print('Please pass *existing* directory name')
	exit()

dirWithFiles = os.listdir(indir)
dirWithFiles.sort

#for azr free tier, max 20 per minute. png, tif, jpg accepted. 
#for free tier tiff only first 1 page ocred. 4s for 1s extra time, to be sure it keeps going

if len(dirWithFiles) > 20:
	pause_time = 4
else:
	pause_time = 0

buffer = ""
ocrtext = ""
print (dirWithFiles)

outocrFile = indir + "-ocrtext.txt"
outbufferFile = indir + "-buffer.txt"

if os.path.exists(outocrFile):
    os.remove(outocrFile)
	
if os.path.exists(outbufferFile):
    os.remove(outbufferFile)

for singleFile in dirWithFiles:
	singleFileWithPath = os.path.join(indir, singleFile)
	print(singleFile) #always inside folder, so no need for ..withPath
	with open(singleFileWithPath, "rb") as fileInsideWithLoop:
		image_data = fileInsideWithLoop.read()
		result = client.analyze(
			image_data=image_data,
			visual_features=[VisualFeatures.READ])

		if result.read is not None:
			buffer += str(result.read)+'\n\n'
			for line in result.read.blocks[0].lines:
				ocrtext += line.text+'\n'
			ocrtext = ocrtext+'\n'
			
		else:
			print(fileInsideWithLoop, 'No data returned, exiting')
			exit()
		
		time.sleep(pause_time)
		
with open(outbufferFile, "w", encoding="utf-8") as fileBufferInsideWithLoop:
	fileBufferInsideWithLoop.write(buffer)

with open(outocrFile, "w", encoding="utf-8") as fileOutputInsideWithLoop:
	fileOutputInsideWithLoop.write(ocrtext)
	
