
#2024-06-12-1

'''
pip install azure-ai-vision-imageanalysis
'''

import os
import time
from azure.core.credentials import AzureKeyCredential
from azure.ai.vision.imageanalysis import ImageAnalysisClient
from azure.ai.vision.imageanalysis.models import VisualFeatures

try:
	endpoint = "ENTER"
	key = "ENTER"
except KeyError:
	print("Missing environment variable 'VISION_ENDPOINT' or 'VISION_KEY'")
	print("Set them before running this sample.")
	exit()

# Create an Image Analysis client
client = ImageAnalysisClient(
	endpoint=endpoint,
	credential=AzureKeyCredential(key)
)

indir = 'ocr'

if not os.path.isdir(indir):
	print('Please pass *existing* directory name')
	exit()

dirWithFiles = os.listdir(indir)
dirWithFiles.sort

#for azr free tier, max 20 per minute. png, tif, jpg accepted. 
#for free tier tiff only first 1 page ocred. 4s for 1s extra time, to be sure it keeps going

if len(dirWithFiles) > 20:
	pause_time = 4
else:
	pause_time = 0

buffer = ""
ocrtext = ""
print (dirWithFiles)

outocrFile = indir + "-ocrtext.txt"
outbufferFile = indir + "-buffer.txt"

if os.path.exists(outocrFile):
    os.remove(outocrFile)
	
if os.path.exists(outbufferFile):
    os.remove(outbufferFile)

for singleFile in dirWithFiles:
	singleFileWithPath = os.path.join(indir, singleFile)
	print(singleFile) #always inside folder, so no need for ..withPath
	with open(singleFileWithPath, "rb") as fileInsideWithLoop:
		image_data = fileInsideWithLoop.read()
		result = client.analyze(
			image_data=image_data,
			visual_features=[VisualFeatures.READ])

		if result.read is not None:
			buffer += str(result.read)+'\n\n'
			for line in result.read.blocks[0].lines:
				ocrtext += line.text+'\n'
			ocrtext = ocrtext+'\n'
			
		else:
			print(fileInsideWithLoop, 'No data returned, exiting')
			exit()
		
		time.sleep(pause_time)
		
with open(outbufferFile, "w", encoding="utf-8") as fileBufferInsideWithLoop:
	fileBufferInsideWithLoop.write(buffer)

with open(outocrFile, "w", encoding="utf-8") as fileOutputInsideWithLoop:
	fileOutputInsideWithLoop.write(ocrtext)
	