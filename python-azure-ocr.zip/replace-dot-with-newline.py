

#2024-06-16-1

import re

filename = '1.txt'
with open(filename, 'r', encoding="utf-8") as file:
    a = file.read()#.replace('\n', '')
	
#print(repr(a))	
	
#when open file in python it replaces all types of newline with \n

outfile = filename + '-outfile.txt'

#a = re.sub(r'\n\n',r'_newline_', a) #empty lines, at start of new file, as newline in final?
a = re.sub(r'\n\n',r'\n', a) #not

a = re.sub(r' -\n',r' - ', a) #not end hyphen, but part of sentence, cannot add \n because it will be replaced with space later, so three would be 2 spaces after -
a = re.sub(r'-\n',r'', a)#remove end of line hyphen
a = re.sub(r'(\.|\?|\!|\:|\"|\“|\„|\”)\n',r'\1\n\n', a)#add newline to . or ? if at the end of line
a = re.sub(r'\n\n',r'_newline_', a) #replace all newlines with _newline_
a = re.sub(r'\n',r' ', a) #remove hardlines
a = re.sub(r'_newline_',r'\n\n', a) # bring back original/correct newline


with open(outfile, "w", encoding="utf-8") as fb:
	fb.write(a)


