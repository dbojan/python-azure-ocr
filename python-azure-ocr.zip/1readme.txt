1convert - convert pdf to png images. in ocr folder, or in current folder

azure ocr - start this when you have image files (png, tif or jpg) in ocr folder.
remember to install python, and use pip to install azure ocr library: pip install azure-ai-vision-imageanalysis
click on azure_ocr.bat to start ocr.

2remove dot from files - remove hard lines from resulting txt file

if more that 10 images, _temp.txt files are created. you can delete these afterwards.


read azure_ocr.py for installation in linux.

changes in 2024-06-30-1
temp files
xpdf for pdf->png