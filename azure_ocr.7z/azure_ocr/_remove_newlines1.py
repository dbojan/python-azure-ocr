
#2025-3-4-1

#to start in linux, in file manager, double click on '*.py' file

import re
import sys
import os

intAddDash = 1
intDashAddSpace = 1

#st_input_file = 'ocr-ocrtext.txt'
#st_input_file = '1.txt'


try:
	st_input_file=sys.argv[1]
except:
	print('Please pass file name')
	exit()


if not os.path.isfile(st_input_file):
	print('exiting, no file:', st_input_file)
	exit()

print('Input file:', st_input_file)



wholetext = ''
intPresetPercentageOfLineLength = 75
intPresetNumberOfLinesToCheck = 120

regexNumbers_Caps_Dots_spaces=re.compile(r'^[A-Z0-9\r\n\ \.\:\;\?\!\-ŠĐČĆŽАБВГДЂЕЖЗИЈКЛЉМНЊОПРСТЋУФХЦЧЏШ]+$')

with open(st_input_file, 'r', encoding="utf-8") as file:
	wholetext = file.read()

	wholeTextLines = wholetext.splitlines()


	#print(len(wholeTextLines)) ;input()
	#Find which number is smaller, 'existing number of lines in text' vs 'default number of lines'
	intNumbersOfLinesInTextTested = min (len(wholeTextLines),intPresetNumberOfLinesToCheck)
		
	#get the longest line length , by comparing previous length, and current
	intMaxLineLengthCalculated = 0
	for i in range(0,    intNumbersOfLinesInTextTested   ):
		intMaxLineLengthCalculated = max( intMaxLineLengthCalculated , len(wholeTextLines[i])  ) 

	
	int80PercentLengthLineInThisText = round ( intMaxLineLengthCalculated/100*intPresetPercentageOfLineLength ) #*****

	
	print (int80PercentLengthLineInThisText,intMaxLineLengthCalculated) #usually around 81
	
	# wholetext = re.sub('^ +','', wholetext, flags=re.MULTILINE) #remove start space(s)
	# wholetext = re.sub(' +$','', wholetext, flags=re.MULTILINE) #remove end space(s)
	# wholetext = re.sub('\n+','\n', wholetext, flags=re.MULTILINE) #resingle newline

	# wholetext = re.sub(r'^[\–|\—|\.|\•|\·|\>|\_]',r'-', wholetext, flags=re.MULTILINE) #replace various bullet lists with -

	# wholetext = re.sub('-+','-', wholetext, flags=re.MULTILINE) #resingle newline
	# wholetext = re.sub('^- +','-', wholetext, flags=re.MULTILINE) #remove space after - at start
	# wholetext = re.sub(' +',r' ', wholetext, flags=re.MULTILINE) #resingle space

	# wholetext = re.sub('^-','', wholetext, flags=re.MULTILINE) #remove - at start

	wholeTextLines = wholetext.splitlines()
	wholeText = ''
	for i in range(0, len(wholeTextLines)   ):

		if regexNumbers_Caps_Dots_spaces.match(wholeTextLines[i]):#caps, numbers, ... 
			wholeText = wholeText + '\n\n' + wholeTextLines[i] + '\n\n'
			continue

		if len(   wholeTextLines[i]    )  <= int80PercentLengthLineInThisText:
			#print('less','line: ', wholeTextLines[i],'everything: ',wholeText);input();
			wholeText = wholeText + wholeTextLines[i]
			if i > -1 and  len(   wholeTextLines[i-1]    )  <= int80PercentLengthLineInThisText:#if previous line was short, add one newline
				wholeText = wholeText + '\n'
			else:
				wholeText = wholeText + '\n\n'
	
		else:
			if i > -1        and         len(   wholeTextLines[i-1]    )  <= int80PercentLengthLineInThisText :
				wholeText = wholeText + '\n'
			wholeText = wholeText + wholeTextLines[i] + ' '

wholeText = wholeText.replace('\n\n\n','\n\n')
wholeText = wholeText.replace('\n\n\n','\n\n')

outfile = st_input_file + '-removed_newlines.txt'
with open(outfile, "w", encoding="utf-8") as fileo:
	fileo.write(wholeText)

