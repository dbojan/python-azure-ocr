

#2026-04-03-1
#pip install -U --break-system-packages google-cloud-vision

#1000 images free per month, reset every 1st of month, above 1000 images, you pay $1.50 per 1,000 images

import os, io
from google.cloud import vision
import re

# Use the key file
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "_key_cloudvision1_text.json"

client = vision.ImageAnnotatorClient()
image_folder = "ocr"
text_output = "ocr-out_Ocr_NoColumnFile.txt"

def reconstruct_from_words(texts, y_threshold=8):
	if not texts: return []
	word_data = []
	# Index 0 is the full block; 1+ are individual words
	for word in texts[1:]:
		v = word.bounding_poly.vertices
		avg_x = sum([vert.x for vert in v]) / 4
		avg_y = sum([vert.y for vert in v]) / 4
		word_data.append((word.description, avg_x, avg_y))

	word_data.sort(key=lambda x: (x[2], x[1]))
	lines, current_line, last_y = [], [], None

	for text, x, y in word_data:
		if last_y is None or abs(y - last_y) < y_threshold:
			current_line.append((text, x))
		else:
			current_line.sort(key=lambda x: x[1])
			lines.append(" ".join([w[0] for w in current_line]))
			current_line = [(text, x)]
		last_y = y
	
	if current_line:
		current_line.sort(key=lambda x: x[1])
		lines.append(" ".join([w[0] for w in current_line]))
	return lines

files = sorted([f for f in os.listdir(image_folder) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.tif'))])
print(f"Starting OCR on {len(files)} files...")

with open(text_output, "w", encoding="utf-8") as out:
	for i, filename in enumerate(files, 1):
		print(f"[{i}/{len(files)}] Processing: {filename}")
		with io.open(os.path.join(image_folder, filename), 'rb') as img_f:
			content = img_f.read()
		
		image = vision.Image(content=content)
		response = client.document_text_detection(image=image)
		
		if response.text_annotations:
			lines = reconstruct_from_words(response.text_annotations)
			wholetext = "\n".join(lines)
			wholetext = re.sub('^·','-', wholetext, flags=re.MULTILINE) #replace '·' at start with '-'
			#for google vision ocr
			# Matches a space followed by any one of the characters inside the brackets
			#wholetext = re.sub(r'\s+([.,:;?!/])', r'\1', wholetext)
			# We add / and \\ to the character set
			# Note: inside [ ], / is just a literal, but \ must be escaped as \\
			wholetext = re.sub(r'\s+([.,:;?!„“"\/\\\\])', r'\1', wholetext)

			#replace ' ' after / and „ ONLY
			# Matches a literal / followed by one or more whitespace characters
			# Replaces it with just the /
			wholetext = re.sub(r'([/„]) +', r'\1', wholetext)
			#out.write("\n" + "\n".join(lines) + "\n")
			out.write("\n" + wholetext + "\n")
