#!/bin/bash
# 2026-04-15-1

#test if tools exist
for c in find nl read
do
	if ! command -v $c >/dev/null
	then
		echo $c is missing
	fi
done


find _ocr_*.py | nl -s ") "
read -p $'\n'"Enter number, or press enter (default 1): " choice

if [ -z "$choice" ]; then
    choice=1
fi

echo "You entered $choice ..."
target=$(find _ocr_*.py | sed -n "${choice}p")

./_call_ocr.sh "$target"

