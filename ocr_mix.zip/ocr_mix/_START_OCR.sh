#!/bin/bash
#start with xterm -e

#2026-04-04-1

files=(_ocr_*.py)

COLUMNS=1
# $'\n' is for empty line
PS3=$'\n'"Enter number [1-${#files[@]}]: "
select choice in "${files[@]}"; do
	./_call_ocr.sh "$choice"
	break
done

