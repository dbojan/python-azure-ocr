#!/bin/bash
#start with xterm -e

#2026-4-4-1


#if you wish to call it directly, us _ocr_xxx.py as argument:
#_call_ocr.sh _ocr_azure1_text.py


#deskew images using deskew, or deskew.exe in others folder. to disable set deskew=0
deskew=1
#log number of files, per month, for each ocr brand used (distinguishing using script name), in file _log.txt. to disable set logfiles=0
logfiles=1

# Ensure we are in the script's directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OCR_DIR="$SCRIPT_DIR/ocr"

# Create ocr dir if it doesn't exist
mkdir -p "$OCR_DIR"

cd "$OCR_DIR" || exit

python_name=python
deskew_app="../others/deskew"

#test if tools exist
for c in pdftoppm "$python_name" "$deskew_app" sed wc grep
do
	if ! command -v $c >/dev/null
	then
		echo $c is missing
	fi
done


# 1. Convert PDF to Images
for g in *.pdf *.PDF; do
	[ -e "$g" ] || continue
	echo "Converting $g to img..."
	
	
	pdftoppm -aa yes -aaVector yes -png -gray -progress "$g" "${g%.pdf}-img"
	# problems with tiff?
	#-tiff -tiffcompression packbits 
	#-png
	#-tiffcompression <string> : set TIFF compression: none, packbits, jpeg, lzw, deflate


	mv "$g" ../
done


if [ -z "$(ls -A "$OCR_DIR")" ]; then
	echo "Error: No files found in $OCR_DIR. Nothing to process."
	read -p "Press [Enter] to exit..." 
	exit 1
fi


cd "$SCRIPT_DIR" || exit

# 2. Cleanup old OCR text files
rm -f *-out_Ocr_*.txt

# 3. List files and wait for user
echo "Files ready for OCR:"
ls "$OCR_DIR" | sort  # Added sort here for visual clarity
echo ""

# FIX: Using -u /dev/tty ensures it waits even in xterm/scripts
echo "Press [Enter] key to start OCR..."
read -r dummy < /dev/tty
echo ""


#DESKEW
if [[ $deskew -eq 1 ]]; then
	cd "$OCR_DIR" || exit
	for g in *.png ; do
		echo "deskewing $g"
		"$deskew_app" -b FFFFFF -f g8 -o "deskewed-${g%}" "$g"
		#move original img files back up, if deskewed files exist
		if [ -f "deskewed-${g%}" ]; then
			mv "$g" ../
		fi
	done
	cd ..
fi


#LOG NUMBER OF FILES PER SCRIPT
if [[ $logfiles -eq 1 ]]; then

	LOG="_log.txt"
	PREFIX="$1"
	DATE_STAMP="$(date +%Y-%m)"
	SEARCH_PATTERN="${PREFIX}_${DATE_STAMP}__"

	# Count files in the directory (handling empty or missing dir)
	num_files=$(ls -1 "$OCR_DIR" 2>/dev/null | wc -l)

	# 2. Check if log.txt exists
	if [ -f "$LOG" ]; then
		# Check if the specific $1_yyyy-mm__ pattern exists in the log
		line=$(grep "^${SEARCH_PATTERN}" "$LOG")
		
		if [ -n "$line" ]; then
			# 3. Get number after __, increase it by num_files, and save log
			current_val=$(echo "$line" | sed "s/.*__//")
			new_val=$((current_val + num_files))
			
			# Use sed to replace the line in-place
			sed -i "s/^${SEARCH_PATTERN}.*$/${SEARCH_PATTERN}${new_val}/" "$LOG"
		else
			# 4. Pattern doesn't exist, append it
			echo "${SEARCH_PATTERN}${num_files}" >> "$LOG"
		fi
	else
		# 5. Log doesn't exist, create it with the initial entry
		echo "${SEARCH_PATTERN}${num_files}" > "$LOG"
	fi

fi









# 4. Run Python OCR scripts
echo "OCR of files in ocr folder..."
"$python_name" "$1"

# 5. Process newlines
ST_INPUT_FILE="ocr-out_Ocr_NoColumnFile.txt"
if [ -f "$ST_INPUT_FILE" ]; then
	echo "Removing extra newlines..."
	"$python_name" _remove_newlines1.py "$ST_INPUT_FILE"
fi

# 6. Cleanup
if [[ $deskew -eq 1 ]]; then
	#remove deskew-* files
	rm -f ocr/deskewed-*
fi
#move original img files back up, if they exist
mv ocr/* . 2>/dev/null



echo "Finished."
read -p "Press [Enter] to exit..." 
