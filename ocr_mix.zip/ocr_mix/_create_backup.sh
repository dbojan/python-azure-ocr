#!/bin/bash

dt="backup/$(date +%Y%m%d-%H%M%S)"
mkdir -p "$dt"
cp -r *.py *.sh *.json "$dt/"
rm -f "$dt/_create_backup.sh"


read -p "done"
