#2026-05-13-1

'''
Converts a .txt file containing plain paragraphs and pandoc grid_tables to .docx.

Supports optional <!--gridtable-meta ... --> comment blocks emitted by
_ocr_azure2_tables.py immediately before each table, carrying:

    cols_px:120.5,80.0,200.3,300.1
    rows_px:40.0,35.0,35.0,35.0
    cell_align:0,0=L,T 0,1=C,M 1,0=R,B ...

When present these are used to set proportional column widths, row heights,
and per-cell horizontal / vertical alignment in the Word table.
When absent the table falls back to full-width equal columns with default
alignment (same behaviour as before).

SAVE FILE FIRST IN GEANY
label:
docx
command:
if py and txt are in the same folder:
sh -c "python _geany_text_and_gridtables_to_docx.py '%f'"


sh -c "python /home/b/data/p_ocr_mix/_geany_text_and_gridtables_to_docx.py '%f' "

Convert & Email:
sh -c "python /home/b/data/p_ocr_mix/_geany_text_and_gridtables_to_docx.py '%f' && /home/b/apps/betterbird/betterbird -compose \"subject='files',attachment='%p/%e.docx'\" "






Convert selected text to Latin/Cyrillic script using geany:
edit/format/send selection to/set custom commands

Label: 
To Latin

Command:
sed 's/Љ/Lj/g; s/љ/lj/g; s/Њ/Nj/g; s/њ/nj/g; s/Џ/Dž/g; s/џ/dž/g; y/абвгдђежзијклмнопрстуфхцчћшАБВГДЂЕЖЗИЈКЛМНОПРСТУФХЦЧЋШ/abvgdđežzijklmnoprstufhcčćšABVGDĐEŽZIJKLMNOPRSTUFHCČĆŠ/'



Label:
To Cyrillic

Command:
sed 's/dž/џ/g; s/Dž/Џ/g; s/DŽ/Џ/g; s/lj/љ/g; s/Lj/Љ/g; s/LJ/Љ/g; s/nj/њ/g; s/Nj/Њ/g; s/NJ/Њ/g; y/abvgdđežzijklmnoprstufhcčćšABVGDĐEŽZIJKLMNOPRSTUFHCČĆŠ/абвгдђежзијклмнопрстуфхцчћшАБВГДЂЕЖЗИЈКЛМНОПРСТУФХЦЧЋШ/'



Command (Cyrillic → Latin):

|Љ |љ |Њ |њ |Џ |џ |а|б|в|г|д|ђ|е|ж|з|и|ј|к|л|м|н|о|п|р|с|т|у|ф|х|ц|ч|ћ|ш|А|Б|В|Г|Д|Ђ|Е|Ж|З|И|Ј|К|Л|М|Н|О|П|Р|С|Т|У|Ф|Х|Ц|Ч|Ћ|Ш|
|Lj|lj|Nj|nj|Dž|dž|a|b|v|g|d|đ|e|ž|z|i|j|k|l|m|n|o|p|r|s|t|u|f|h|c|č|ć|š|A|B|V|G|D|Đ|E|Ž|Z|I|J|K|L|M|N|O|P|R|S|T|U|F|H|C|Č|Ć|Š|


Command (Latin → Cyrillic):

|dž|Dž|DŽ|lj|Lj|LJ|nj|Nj|NJ|a|b|v|g|d|đ|e|ž|z|i|j|k|l|m|n|o|p|r|s|t|u|f|h|c|č|ć|š|A|B|V|G|D|Đ|E|Ž|Z|I|J|K|L|M|N|O|P|R|S|T|U|F|H|C|Č|Ć|Š|
|џ |Џ |Џ |љ |Љ |Љ |њ |Њ |Њ |а|б|в|г|д|ђ|е|ж|з|и|ј|к|л|м|н|о|п|р|с|т|у|ф|х|ц|ч|ћ|ш|А|Б|В|Г|Д|Ђ|Е|Ж|З|И|Ј|К|Л|М|Н|О|П|Р|С|Т|У|Ф|Х|Ц|Ч|Ћ|Ш|


'''

import sys
import os
from docx import Document
from docx.shared import Pt, Mm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.oxml.ns import qn
from docx.oxml import OxmlElement


# ── tunables ──────────────────────────────────────────────────────────────────
FONT_NAME = 'Times New Roman'
FONT_SIZE = Pt(12)
# Page geometry used for proportional column width conversion
PAGE_WIDTH_IN  = 8.27   # A4
PAGE_MARGIN_IN = 1.0    # 25.4 mm each side
# Source document DPI used when the OCR script recorded pixel measurements
SOURCE_DPI = 96.0
# ──────────────────────────────────────────────────────────────────────────────


# ── metadata letter maps ──────────────────────────────────────────────────────
_H_MAP = {
    'L': WD_ALIGN_PARAGRAPH.LEFT,
    'C': WD_ALIGN_PARAGRAPH.CENTER,
    'R': WD_ALIGN_PARAGRAPH.RIGHT,
    'J': WD_ALIGN_PARAGRAPH.JUSTIFY,
}
_V_MAP = {
    'T': WD_ALIGN_VERTICAL.TOP,
    'M': WD_ALIGN_VERTICAL.CENTER,
    'B': WD_ALIGN_VERTICAL.BOTTOM,
}


# ── docx helpers ──────────────────────────────────────────────────────────────

def set_cell_font(cell, h_align=None, v_align=None):
    if v_align is not None:
        cell.vertical_alignment = v_align
    for para in cell.paragraphs:
        para.alignment = h_align if h_align is not None else WD_ALIGN_PARAGRAPH.LEFT
        para.paragraph_format.space_after  = Pt(0)
        para.paragraph_format.space_before = Pt(0)
        for run in para.runs:
            run.font.name = FONT_NAME
            run.font.size = FONT_SIZE
            rpr    = run._element.get_or_add_rPr()
            rFonts = rpr.get_or_add_rFonts()
            rFonts.set(qn('w:ascii'), FONT_NAME)
            rFonts.set(qn('w:hAnsi'), FONT_NAME)


def make_table_full_width(docx_table):
    tbl   = docx_table._tbl
    tblPr = tbl.find(qn('w:tblPr'))
    if tblPr is None:
        tblPr = OxmlElement('w:tblPr')
        tbl.insert(0, tblPr)
    for tag in ('w:tblW', 'w:tblInd', 'w:tblLayout'):
        el = tblPr.find(qn(tag))
        if el is not None:
            tblPr.remove(el)
    tblStyle = tblPr.find(qn('w:tblStyle'))
    anchor   = tblStyle if tblStyle is not None else tblPr

    tblW = OxmlElement('w:tblW')
    tblW.set(qn('w:w'),    '5000')
    tblW.set(qn('w:type'), 'pct')
    anchor.addnext(tblW)

    tblInd = OxmlElement('w:tblInd')
    tblInd.set(qn('w:w'),    '0')
    tblInd.set(qn('w:type'), 'dxa')
    tblW.addnext(tblInd)

    tblLayout = OxmlElement('w:tblLayout')
    tblLayout.set(qn('w:type'), 'fixed')
    tblInd.addnext(tblLayout)

    # Set every cell's tcW to type=pct with equal shares so columns
    # also reflow when page margins change (not just the table border).
    num_cols = len(docx_table.columns)
    if num_cols > 0:
        per_col = 5000 // num_cols
        last_col_pct = 5000 - per_col * (num_cols - 1)
        for ri, row in enumerate(docx_table.rows):
            for ci, cell in enumerate(row.cells):
                tc   = cell._tc
                tcPr = tc.find(qn('w:tcPr'))
                if tcPr is None:
                    tcPr = OxmlElement('w:tcPr')
                    tc.insert(0, tcPr)
                tcW = tcPr.find(qn('w:tcW'))
                if tcW is None:
                    tcW = OxmlElement('w:tcW')
                    tcPr.append(tcW)
                pct = last_col_pct if ci == num_cols - 1 else per_col
                tcW.set(qn('w:w'),    str(pct))
                tcW.set(qn('w:type'), 'pct')


def apply_col_widths(docx_table, col_widths_in, num_rows, num_cols):
    """
    Set proportional column widths on tblGrid and every cell.
    tblW stays as pct 5000 (100% of content area) so the table always
    reflows correctly when page margins change in LibreOffice or Word.
    Column widths are stored as pct fractions that sum to 5000.
    """
    tbl     = docx_table._tbl
    tblGrid = tbl.find(qn('w:tblGrid'))
    if tblGrid is None:
        tblGrid = OxmlElement('w:tblGrid')
        tbl.insert(0, tblGrid)
    for gc in tblGrid.findall(qn('w:gridCol')):
        tblGrid.remove(gc)

    total_in  = sum(col_widths_in) or 1.0
    # Express each column as a share of 5000 (the pct unit Word uses for tblW)
    col_pct   = [round(w / total_in * 5000) for w in col_widths_in]
    # Fix any rounding drift so they sum exactly to 5000
    drift = 5000 - sum(col_pct)
    col_pct[-1] += drift

    for pct in col_pct:
        gc = OxmlElement('w:gridCol')
        # gridCol w= is in twips; use pct*content_w/5000 but we don't know
        # the actual content width here, so use a nominal A4 content width
        # (6.27 in) — Word/LO recalculates from tblGrid proportions anyway.
        gc.set(qn('w:w'), str(int(pct / 5000 * 6.27 * 1440)))
        tblGrid.append(gc)

    # Set per-cell tcW as type=pct so they also scale with page width
    for ci, pct in enumerate(col_pct):
        for ri in range(num_rows):
            tc   = docx_table.cell(ri, ci)._tc
            tcPr = tc.find(qn('w:tcPr'))
            if tcPr is None:
                tcPr = OxmlElement('w:tcPr')
                tc.insert(0, tcPr)
            tcW = tcPr.find(qn('w:tcW'))
            if tcW is None:
                tcW = OxmlElement('w:tcW')
                tcPr.append(tcW)
            tcW.set(qn('w:w'),    str(pct))
            tcW.set(qn('w:type'), 'pct')


def apply_row_heights(docx_table, row_heights_in, num_rows):
    for ri, h_in in enumerate(row_heights_in[:num_rows]):
        tr   = docx_table.rows[ri]._tr
        trPr = tr.find(qn('w:trPr'))
        if trPr is None:
            trPr = OxmlElement('w:trPr')
            tr.insert(0, trPr)
        trHeight = trPr.find(qn('w:trHeight'))
        if trHeight is None:
            trHeight = OxmlElement('w:trHeight')
            trPr.append(trHeight)
        trHeight.set(qn('w:val'),   str(max(1, int(h_in * 1440))))
        trHeight.set(qn('w:hRule'), 'atLeast')


def add_paragraph(doc, text):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_after  = Pt(0)
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.line_spacing = 1.0
    run = p.add_run(text)
    run.font.name = FONT_NAME
    run.font.size = FONT_SIZE
    rFonts = run._element.rPr.get_or_add_rFonts()
    rFonts.set(qn('w:ascii'), FONT_NAME)
    rFonts.set(qn('w:hAnsi'), FONT_NAME)


# ── metadata parser ───────────────────────────────────────────────────────────

def parse_meta(meta_lines):
    """
    Parse lines from inside a <!--gridtable-meta ... --> block.
    Returns dict with keys: cols_px, rows_px, cell_align (each None if absent).
    """
    result = {'cols_px': None, 'rows_px': None, 'cell_align': None}
    for line in meta_lines:
        line = line.strip()
        if line.startswith('cols_px:'):
            vals = line[8:].split(',')
            result['cols_px'] = [float(x) for x in vals if x.strip()]
        elif line.startswith('rows_px:'):
            vals = line[8:].split(',')
            result['rows_px'] = [float(x) for x in vals if x.strip()]
        elif line.startswith('cell_align:'):
            align_map = {}
            for token in line[11:].split():
                if '=' not in token:
                    continue
                coords, codes = token.split('=', 1)
                parts_c = coords.split(',')
                if len(parts_c) < 2:
                    continue
                ri, ci   = int(parts_c[0]), int(parts_c[1])
                parts_hv = codes.split(',')
                h_letter = parts_hv[0].strip() if len(parts_hv) > 0 else ''
                v_letter = parts_hv[1].strip() if len(parts_hv) > 1 else ''
                align_map[(ri, ci)] = (_H_MAP.get(h_letter), _V_MAP.get(v_letter))
            result['cell_align'] = align_map
    return result


def px_to_inches(col_px):
    """Convert raw pixel column widths to proportional inch widths."""
    content_w = PAGE_WIDTH_IN - 2 * PAGE_MARGIN_IN
    total_px  = sum(col_px)
    if total_px <= 0:
        n = len(col_px)
        return [content_w / n] * n
    return [w / total_px * content_w for w in col_px]


def px_rows_to_inches(row_px):
    """Convert pixel row heights to inches."""
    return [h / SOURCE_DPI for h in row_px]


# ── grid_table parser ─────────────────────────────────────────────────────────

def is_separator_line(line):
    s = line.rstrip('\n\r')
    if not s.startswith('+'):
        return False
    # Must contain at least one '-' or '=' (rules out bare '+' or all-space lines)
    if not any(c in '-=' for c in s):
        return False
    return all(c in '+-= ' for c in s)


def parse_separator(line):
    s = line.rstrip('\n\r')
    segments = []
    i = 1 if s and s[0] == '+' else 0
    while i < len(s):
        start = i
        while i < len(s) and s[i] != '+':
            i += 1
        seg_str = s[start:i]
        if not seg_str:
            i += 1
            continue
        if all(c == ' ' for c in seg_str):
            segments.append({'kind': 'space', 'sep': ' ', 'width': len(seg_str)})
        elif '=' in seg_str:
            segments.append({'kind': 'rule', 'sep': '=', 'width': len(seg_str)})
        else:
            segments.append({'kind': 'rule', 'sep': '-', 'width': len(seg_str)})
        i += 1
    return segments


def col_boundaries_from_separator(segments):
    positions = [0]
    pos = 0
    for seg in segments:
        pos += seg['width'] + 1
        positions.append(pos)
    return positions


def find_col_boundaries(separator_lines_parsed):
    all_positions = set()
    for segs in separator_lines_parsed:
        for p in col_boundaries_from_separator(segs):
            all_positions.add(p)
    return sorted(all_positions)


def parse_grid_table(table_lines):
    """Parse grid_table lines → (cells, num_rows, num_cols, header_rows)."""
    # Step 1: global column boundaries
    sep_parsed = []
    for line in table_lines:
        if is_separator_line(line):
            sep_parsed.append(parse_separator(line))
    if not sep_parsed:
        return [], 0, 0, 0

    boundaries = find_col_boundaries(sep_parsed)
    num_cols   = len(boundaries) - 1
    pos_to_col = {p: i for i, p in enumerate(boundaries)}

    # Step 2: collect raw cells
    cells        = []
    row_index    = -1
    header_rows  = 0
    prev_was_sep = True

    for line in table_lines:
        s = line.rstrip('\n\r')
        if is_separator_line(s):
            segs = parse_separator(s)
            if row_index >= 0 and any(seg['sep'] == '=' for seg in segs):
                header_rows = row_index + 1
            prev_was_sep = True
        else:
            if prev_was_sep:
                row_index   += 1
                prev_was_sep = False
            if not s.startswith('|'):
                continue
            bar_positions = [j for j, ch in enumerate(s) if ch == '|']
            for k in range(len(bar_positions) - 1):
                left_bar  = bar_positions[k]
                right_bar = bar_positions[k + 1]
                text      = s[left_bar + 1:right_bar].strip()
                ci_start  = pos_to_col.get(left_bar)
                if ci_start is None:
                    continue
                ci_end = pos_to_col.get(right_bar)
                if ci_end is None:
                    for bp in boundaries:
                        if bp > right_bar:
                            ci_end = pos_to_col[bp]
                            break
                if ci_end is None:
                    ci_end = ci_start + 1
                cs = max(1, ci_end - ci_start)
                cells.append({'ri': row_index, 'ci': ci_start,
                               'rs': 1, 'cs': cs, 'text': text})

    num_rows = row_index + 1

    # Step 3: rowspan detection
    sep_after    = []
    row_idx_scan = -1
    prev_sep     = True
    for line in table_lines:
        s2 = line.rstrip('\n\r')
        if is_separator_line(s2):
            if row_idx_scan >= 0:
                segs = parse_separator(s2)
                sep_after.append((row_idx_scan, segs,
                                  col_boundaries_from_separator(segs)))
            prev_sep = True
        else:
            if prev_sep and s2.startswith('|'):
                row_idx_scan += 1
                prev_sep      = False

    for c in cells:
        ri, ci   = c['ri'], c['ci']
        col_left = boundaries[ci]
        rs = 1
        for after_ri, segs, seg_pos in sep_after:
            if after_ri != ri + rs - 1:
                continue
            for idx, seg in enumerate(segs):
                if seg_pos[idx] == col_left and seg['kind'] == 'space':
                    rs += 1
                    break
            else:
                break
        c['rs'] = rs

    # Step 4: drop interior (continuation) cells
    interior = set()
    for c in cells:
        ri, ci, rs, cs = c['ri'], c['ci'], c['rs'], c['cs']
        for dr in range(rs):
            for dc in range(cs):
                if dr == 0 and dc == 0:
                    continue
                interior.add((ri + dr, ci + dc))
    cells = [c for c in cells if (c['ri'], c['ci']) not in interior]

    return cells, num_rows, num_cols, header_rows


# ── docx table renderer ───────────────────────────────────────────────────────

def render_grid_table(doc, cells, num_rows, num_cols, header_rows, meta=None):
    if not cells or num_rows == 0 or num_cols == 0:
        return

    docx_table = doc.add_table(rows=num_rows, cols=num_cols)
    docx_table.style = 'Table Grid'

    # Always set up full-width tblW/tblInd/tblLayout first so the XML
    # elements exist; apply_col_widths then overwrites tblW with the
    # exact fixed width when proportional columns are available.
    make_table_full_width(docx_table)

    # ── Column widths ─────────────────────────────────────────────────────────
    if meta and meta.get('cols_px'):
        col_widths_in = px_to_inches(meta['cols_px'])
        # Pad / trim to num_cols in case of mismatch
        if len(col_widths_in) < num_cols:
            avg = sum(col_widths_in) / len(col_widths_in)
            col_widths_in += [avg] * (num_cols - len(col_widths_in))
        col_widths_in = col_widths_in[:num_cols]
        apply_col_widths(docx_table, col_widths_in, num_rows, num_cols)

    # ── Row heights ───────────────────────────────────────────────────────────
    if meta and meta.get('rows_px'):
        row_heights_in = px_rows_to_inches(meta['rows_px'])
        apply_row_heights(docx_table, row_heights_in, num_rows)

    # ── Per-cell alignment lookup ─────────────────────────────────────────────
    cell_align = (meta or {}).get('cell_align') or {}

    # ── Place cells ───────────────────────────────────────────────────────────
    occupied = set()

    for c in sorted(cells, key=lambda x: (x['ri'], x['ci'])):
        ri, ci, rs, cs, text = c['ri'], c['ci'], c['rs'], c['cs'], c['text']

        if (ri, ci) in occupied:
            continue

        docx_cell = docx_table.cell(ri, ci)

        if rs > 1 or cs > 1:
            end_ri   = min(ri + rs - 1, num_rows - 1)
            end_ci   = min(ci + cs - 1, num_cols - 1)
            end_cell = docx_table.cell(end_ri, end_ci)
            docx_cell = docx_cell.merge(end_cell)
            for mr in range(ri, end_ri + 1):
                for mc in range(ci, end_ci + 1):
                    if not (mr == ri and mc == ci):
                        occupied.add((mr, mc))

        docx_cell.text = text

        h_align, v_align = cell_align.get((ri, ci), (None, None))
        set_cell_font(docx_cell, h_align=h_align, v_align=v_align)

        # Bold header cells
        if ri < header_rows:
            for para in docx_cell.paragraphs:
                for run in para.runs:
                    run.bold = True

    doc.add_paragraph('\u00A0')  # blank line after table


# ── main converter ────────────────────────────────────────────────────────────

def convert(txt_file_path):
    if not os.path.exists(txt_file_path):
        print(f"Error: File '{txt_file_path}' not found.")
        return

    base_name      = os.path.splitext(txt_file_path)[0]
    docx_file_path = f"{base_name}.docx"

    doc     = Document()
    section = doc.sections[0]
    section.page_height  = Mm(297)
    section.page_width   = Mm(210)
    section.left_margin  = section.right_margin  = Mm(25.4)
    section.top_margin   = section.bottom_margin = Mm(25.4)

    with open(txt_file_path, 'r', encoding='utf-8') as f:
        all_lines = f.readlines()

    i = 0
    while i < len(all_lines):
        line = all_lines[i]

        # ── metadata comment block ────────────────────────────────────────────
        if line.rstrip('\n\r') == '<!--gridtable-meta':
            meta_lines = []
            i += 1
            while i < len(all_lines) and all_lines[i].rstrip('\n\r') != '-->':
                meta_lines.append(all_lines[i])
                i += 1
            i += 1  # skip '-->'
            pending_meta = parse_meta(meta_lines)
            # Collect the table that immediately follows
            table_lines = []
            while i < len(all_lines):
                l = all_lines[i]
                if is_separator_line(l) or l.startswith('|'):
                    table_lines.append(l)
                    i += 1
                else:
                    break
            cells, num_rows, num_cols, header_rows = parse_grid_table(table_lines)
            render_grid_table(doc, cells, num_rows, num_cols, header_rows,
                              meta=pending_meta)
            continue

        # ── plain grid_table (no metadata) ───────────────────────────────────
        if is_separator_line(line):
            table_lines = [line]
            i += 1
            while i < len(all_lines):
                l = all_lines[i]
                if is_separator_line(l) or l.startswith('|'):
                    table_lines.append(l)
                    i += 1
                else:
                    break
            cells, num_rows, num_cols, header_rows = parse_grid_table(table_lines)
            render_grid_table(doc, cells, num_rows, num_cols, header_rows,
                              meta=None)
            continue

        # ── regular paragraph ─────────────────────────────────────────────────
        add_paragraph(doc, line.strip('\n\r'))
        i += 1

    doc.save(docx_file_path)
    print(f"Successfully converted '{txt_file_path}' to '{docx_file_path}'")


if __name__ == '__main__':
    if len(sys.argv) > 1:
        convert(sys.argv[1])
    else:
        print("Usage: python _geany_gridtables_to_docx.py <your_file.txt>")
