see readme.md at https://github.com/dbojan/python-azure-ocr/

put pdf in ocr folder, start .bat file. azure account needed.
enter your data in azure.py

endpoint = "https://.."
key = "123.."


pdf2png from xpdf package is also included for windows
for linux install poppler and use pdftoppm

deskew is from https://github.com/galfar/deskew

----
setting up: Google Cloud Vision API

https://console.cloud.google.com/welcome?pli=1&project=lateral-layout-282411
search for 'Cloud Vision API' and enable

||| / IAM & admin / service accouns

create service account

enter service account name: 'ocr1'
account id: will be automatically filled
description: enter 'ocr if you want.

click on 'create and continue'.

now. do not continue on this screen, click on 'service accounts' again (on the left). you should see your new service account created.

click on email, then on 'keys' tab on top
add key/create new key
select json, click create

json file will be downloaded to your pc
rename it to _google_key.json


enable billing:
||| , then Billing
'link billing account'
'create billing account'

you will need valid debit or credit card.

you should probably set budget (alert) to something like $1, in ||| billings/budgets and alerts/create budget

---