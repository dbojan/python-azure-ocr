
@echo off
rem #2025-09-17-1

cd /d "%~dp0%ocr"

for %%g  in (*.pdf) do (
echo converting pdf to img, if any ...
..\others\xpdf\pdftopng.exe -r 300 -gray  "%%g" "%%g-img"
move "%%g" "..\"
)

cd /d "%~dp0%"

if exist "output.docx" del "output.docx"

dir ocr\
echo.
echo press any key to ocr files ...
echo.
pause 

echo ocr of files in ocr folder ...

python _ocr_azure2_tables.py

move ocr\*.* .
echo finished.

pause



exit /b

