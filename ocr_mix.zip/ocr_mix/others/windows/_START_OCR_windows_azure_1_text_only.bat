
@echo off
rem #2025-09-17-1

cd /d "%~dp0%ocr"

for %%g  in (*.pdf) do (
echo converting pdf to img, if any ...
..\others\xpdf\pdftopng.exe -r 300 -gray  "%%g" "%%g-img"
move "%%g" "..\"
)

cd /d "%~dp0%"

if exist "*-out_Ocr_*.txt" del "*-out_Ocr_*.txt"


dir ocr\
echo.
echo press any key to ocr files ...
echo.
pause 

echo ocr of files in ocr folder ...

python _ocr_azure1_text.py


set st_input_file=ocr-out_Ocr_File.txt
rem echo "%st_input_file%"

echo removing extra newlines ...
REM python _remove_newlines.py "%st_input_file%"

set st_input_file=ocr-out_Ocr_NoColumnFile.txt
python _remove_newlines1.py "%st_input_file%"

move ocr\*.* .
rem del /q /s 
REM del ocr-out_Ocr_Buffer*.txt
REM del ocr-out_Ocr_File*.txt

echo finished.

pause



exit /b
rem -f 1 -l 3

